package com.jes.entitygraphsandbox;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import java.util.List;
import java.util.stream.Collectors;

public class Utils {
    public static void main(String[] args) {
        String jsonString = "{\"person\": {\"name\": \"John\", \"age\": 30, \"address\": [{\"street\": \"Main St\", \"city\": \"Anytown\"}]}}";
        Configuration configuration = Configuration.builder().options(Option.AS_PATH_LIST).build();

        List<String> allPaths = JsonPath.using(configuration).parse(jsonString).read("$..*");

        allPaths.stream()
                .map(Utils::toDotDelineation).forEach(System.out::println);
    }

    private static String toDotDelineation(String jsonPath) {
        // We use dot notation to split jsonPaths, but our jsonPath library will only output in bracket notation
        // From: "[field][1][otherField]" or "field[1].otherfield"
        // To: "field.1.otherField"

        jsonPath = jsonPath
                .replace("$", "")
                .replaceAll("\\[(?=[*|\\d])", ".") // Captures [ next to * or 1-9
                .replaceAll("\\[(?![*|\\d])", "")  // Captures [ next to all other characters
                .replace("]", ".")
                .replace("..", ".")
                .replace(".0", "")
                .replace("'", "");
        return removeTrailingPeriod(jsonPath);
    }

    private static String removeTrailingPeriod(String jsonPath) {
        String[] jsonPathArray = jsonPath.split("\\.");
        return String.join(".", jsonPathArray);
    }
}
