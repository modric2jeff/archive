package com.jes.entitygraphsandbox.repository;

import com.cosium.spring.data.jpa.entity.graph.domain.EntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.jes.entitygraphsandbox.entity.Craft;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CraftRepositoryDynamic extends EntityGraphJpaRepository<Craft, Long> {
    Optional<Craft> findOneById(Long id, EntityGraph eg);
}
