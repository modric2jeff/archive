select a1x0_.id as id1_0_, a1x0_.name as name2_0_
from a1 a1x0_