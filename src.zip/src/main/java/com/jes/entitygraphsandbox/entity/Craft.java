package com.jes.entitygraphsandbox.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Craft {

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    //@JsonManagedReference
    @OneToMany(
            mappedBy = "craft",
            orphanRemoval = true,
            cascade = {CascadeType.ALL})
    private Set<WorkInfo> workInfos = new HashSet<>();

    public static void main(String[] args) throws JsonProcessingException {
        Craft craft = new Craft();
        craft.setName("demo-craft");

        WorkInfo workInfo = new WorkInfo();
        workInfo.setWname("wname-1");

        WorkInfo workInfo2 = new WorkInfo();
        workInfo2.setWname("wname-2");

        WorkInfo workInfo3 = new WorkInfo();
        workInfo3.setWname("wname-3");

        WorkInfo workInfo4 = new WorkInfo();
        workInfo4.setWname("wname-4");

        workInfo.setChilds(Set.of(workInfo2));
        workInfo2.setChilds(Set.of(workInfo3));
        workInfo3.setChilds(Set.of(workInfo4));

        Set<WorkInfo> sets = new HashSet<>();
        sets.add(workInfo);
        sets.add(workInfo2);
        sets.add(workInfo3);
        sets.add(workInfo4);
        craft.setWorkInfos(sets);

        WorkSection workSection = new WorkSection();
        workSection.setWsname("wsname-1");
        WorkSection workSection2 = new WorkSection();
        workSection2.setWsname("wsname-2");
        Set<WorkSection> sets1 = new HashSet<>();
        sets1.add(workSection);
        sets1.add(workSection2);
        workInfo.setWorkSections(sets1);


        WorkSection workSection3 = new WorkSection();
        workSection3.setWsname("wsname-3");
        WorkSection workSection4 = new WorkSection();
        workSection4.setWsname("wsname-4");
        Set<WorkSection> sets2 = new HashSet<>();
        sets2.add(workSection3);
        sets2.add(workSection4);
        workInfo4.setWorkSections(sets2);

        WorkSection workSection5 = new WorkSection();
        workSection5.setWsname("wsname-5");
        WorkSection workSection6 = new WorkSection();
        workSection6.setWsname("wsname-6");
        Set<WorkSection> sets3 = new HashSet<>();
        sets3.add(workSection5);
        sets3.add(workSection6);
        workInfo2.setWorkSections(sets3);

        WorkSection workSection7 = new WorkSection();
        workSection7.setWsname("wsname-7");
        Set<WorkSection> sets4 = new HashSet<>();
        sets4.add(workSection7);
        workInfo3.setWorkSections(sets4);


        ObjectMapper objectMapper = new ObjectMapper();
        System.out.println(objectMapper.writeValueAsString(craft));
    }
}
