package com.jes.entitygraphsandbox.entity;

import lombok.Data;

import java.util.List;

@Data
public class RelativeConfig {
    private String model;
    private List<ReleativeItem> releative;

    @Data
    public static class ReleativeItem {
        private String fieldName;
        private String type;
    }
}
