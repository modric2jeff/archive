package com.jes.entitygraphsandbox.entity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class JsonTreeWalker {

    Map<String, PersistConfig> persistConfigs;
    Map<String, RelativeConfig> relativeConfigs;

    ObjectMapper objectMapper = new ObjectMapper();

    List<Object> crafts = new ArrayList<>();

    public JsonTreeWalker(List<PersistConfig> persistConfigs, List<RelativeConfig> relativeConfigs) {
        this.persistConfigs = persistConfigs.stream()
                .collect(Collectors.toMap(PersistConfig::getPathlevel, Function.identity()));
        this.relativeConfigs = relativeConfigs.stream()
                .collect(Collectors.toMap(RelativeConfig::getModel, Function.identity()));
    }

    public void walkTree(JsonNode root, TreeContext treeContext) {
        walker("", root, treeContext);
    }

    private void walker(String nodePath, JsonNode node, TreeContext treeContext) {
        if (node.isObject()) {
            if (persistConfigs.containsKey(nodePath)) {
                PersistConfig persistConfig = persistConfigs.get(nodePath);
                switch (persistConfig.getModel()) {
                    case "Craft":
                        Craft craft = objectMapper.convertValue(node, Craft.class);
                        crafts.add(craft);
                        treeContext.getData().put(persistConfig.getModel(),
                                persistConfig.getPrimary().stream().map(s ->
                                        node.get(s).asText()).collect(Collectors.toList()));
                        break;
                    case "WorkInfo":
                        WorkInfo workInfo = objectMapper.convertValue(node, WorkInfo.class);
                        crafts.add(workInfo);

                        treeContext.getData().put(persistConfig.getModel(),
                                persistConfig.getPrimary().stream().map(s ->
                                        node.get(s).asText()).collect(Collectors.toList()));

                        break;
                    case "WorkSection":
                        WorkSection workSection = objectMapper.convertValue(node, WorkSection.class);
                        crafts.add(workSection);

                        treeContext.getData().put(persistConfig.getModel(),
                                persistConfig.getPrimary().stream().map(s ->
                                        node.get(s).asText()).collect(Collectors.toList()));

                        break;
                    default:
                        ;
                }
            }
            node.fields().forEachRemaining(e -> walker((nodePath.isEmpty()) ? e.getKey() : nodePath + "." + e.getKey(), e.getValue(), treeContext));
        } else if (node.isArray()) {
            node.elements().forEachRemaining(n -> walker(nodePath, n, treeContext));
        } else {
            //do nothing
        }
//        else {
//            if (node.isValueNode()) {
//                consumer.accept(nameToPrint, node.asText());
//            } else {
//                throw new IllegalStateException("Node must be one of value, array or object.");
//            }
//        }
    }
}
