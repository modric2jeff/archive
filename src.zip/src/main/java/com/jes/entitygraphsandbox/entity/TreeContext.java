package com.jes.entitygraphsandbox.entity;

import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class TreeContext {

    private Map<String, List<String>> data = new HashMap<>();
}
