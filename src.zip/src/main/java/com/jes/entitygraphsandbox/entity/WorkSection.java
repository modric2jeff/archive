package com.jes.entitygraphsandbox.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class WorkSection {
    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Include
    private String wsname;

    //@JsonBackReference(value = "workInfo")
    @ManyToOne(fetch = FetchType.EAGER)
    private WorkInfo workInfo;
}
