package com.jes.entitygraphsandbox.entity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ModelSink {

    public static void main(String[] args) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        List<PersistConfig> persistConfigList = objectMapper.readValue(new File("D:\\bat\\config.json"), new TypeReference<List<PersistConfig>>() {
        });

        List<RelativeConfig> relativeConfigs = objectMapper.readValue(new File("D:\\bat\\relative.json"), new TypeReference<List<RelativeConfig>>() {
        });

        JsonNode datanode = objectMapper.readTree(new File("D:\\bat\\test.json"));

        JsonTreeWalker jsonTreeWalker = new JsonTreeWalker(persistConfigList, relativeConfigs);
        jsonTreeWalker.walkTree(datanode, new TreeContext());
        System.out.println("finish");

    }


}
