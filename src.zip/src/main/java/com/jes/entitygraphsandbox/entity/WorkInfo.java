package com.jes.entitygraphsandbox.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class WorkInfo {
    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Include
    private String wname;

    //@JsonBackReference(value = "parent")
    @ManyToOne(fetch = FetchType.EAGER)
    private WorkInfo parent;

    //@JsonManagedReference
    @OneToMany(mappedBy = "parent",
            orphanRemoval = true,
            cascade = {CascadeType.ALL})
    private Set<WorkInfo> childs;

    //@JsonBackReference(value = "craft")
    @ManyToOne(fetch = FetchType.EAGER)
    private Craft craft;

    //@JsonManagedReference
    @OneToMany(
            mappedBy = "workInfo",
            orphanRemoval = true,
            cascade = {CascadeType.ALL})
    private Set<WorkSection> workSections = new HashSet<>();
}
