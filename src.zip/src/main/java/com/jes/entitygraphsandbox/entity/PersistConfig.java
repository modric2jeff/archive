package com.jes.entitygraphsandbox.entity;

import lombok.Data;

import java.util.List;

@Data
public class PersistConfig {
    private String pathlevel;
    private String model;
    private List<String> primary;
}
