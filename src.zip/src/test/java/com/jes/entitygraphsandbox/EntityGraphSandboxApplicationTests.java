package com.jes.entitygraphsandbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntityGraphSandboxApplicationTests {

    @Test
    void contextLoads() {
    }

}
