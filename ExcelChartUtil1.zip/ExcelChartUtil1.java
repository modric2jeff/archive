/* ====================================================================
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */
package test.common;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.PresetColor;
import org.apache.poi.xddf.usermodel.XDDFColor;
import org.apache.poi.xddf.usermodel.XDDFShapeProperties;
import org.apache.poi.xddf.usermodel.XDDFSolidFillProperties;
import org.apache.poi.xddf.usermodel.chart.AxisCrosses;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.BarDirection;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.XDDFBarChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Line chart example.
 */
public class ExcelChartUtil1 {
	public static void main(String[] args) throws IOException {
		barColumnChart();
//        try (XSSFWorkbook wb = new XSSFWorkbook()) {
//            XSSFSheet sheet = wb.createSheet("barchart");
//            final int NUM_OF_ROWS = 3;
//            final int NUM_OF_COLUMNS = 10;
//
//            // Create a row and put some cells in it. Rows are 0 based.
//            Row row;
//            Cell cell;
//            for (int rowIndex = 0; rowIndex < NUM_OF_ROWS; rowIndex++) {
//                row = sheet.createRow((short) rowIndex);
//                for (int colIndex = 0; colIndex < NUM_OF_COLUMNS; colIndex++) {
//                    cell = row.createCell((short) colIndex);
//                    cell.setCellValue(colIndex * (rowIndex + 1.0));
//                }
//            }
//
//            XSSFDrawing drawing = sheet.createDrawingPatriarch();
//            XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 5, 10, 15);
//
//            XSSFChart chart = drawing.createChart(anchor);
//            chart.setTitleText("BarChart");
//            chart.setTitleOverlay(false);
//            XDDFChartLegend legend = chart.getOrAddLegend();
//            legend.setPosition(LegendPosition.TOP_RIGHT);
//
//            // Use a category axis for the bottom axis.
//            XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
//            bottomAxis.setTitle("x"); 
//            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
//            leftAxis.setTitle("f(x)");
//            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
//
//            XDDFDataSource<Double> xs = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(0, 0, 0, NUM_OF_COLUMNS - 1));
//            XDDFNumericalDataSource<Double> ys1 = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(1, 1, 0, NUM_OF_COLUMNS - 1));
//            XDDFNumericalDataSource<Double> ys2 = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(2, 2, 0, NUM_OF_COLUMNS - 1));
//
//            XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
//            XDDFChartData.Series series1 = data.addSeries(xs, ys1);
//            series1.setTitle("2x", null);
//            XDDFChartData.Series series2 = data.addSeries(xs, ys2);
//            series2.setTitle("3x", null);
//            chart.plot(data);
//
//            // in order to transform a bar chart into a column chart, you just need to change the bar direction
//            XDDFBarChartData bar = (XDDFBarChartData) data;
//            bar.setBarDirection(BarDirection.COL);
//            // looking for "Stacked Bar Chart"? uncomment the following line
//            // bar.setBarGrouping(BarGrouping.STACKED);
//
//            solidFillSeries(data, 0, PresetColor.CHARTREUSE);
//            solidFillSeries(data, 1, PresetColor.TURQUOISE);
//
//            // Write the output to a file
//            try (FileOutputStream fileOut = new FileOutputStream("D:\\test\\ooxml-bar-chart.xlsx")) {
//                wb.write(fileOut);
//            }
//        }
    }

    private static void solidFillSeries(XDDFChartData data, int index, PresetColor color) {
        XDDFSolidFillProperties fill = new XDDFSolidFillProperties(XDDFColor.from(color));
        XDDFChartData.Series series = data.getSeries().get(index);
        XDDFShapeProperties properties = series.getShapeProperties();
        if (properties == null) {
            properties = new XDDFShapeProperties();
        }
        properties.setFillProperties(fill);
        series.setShapeProperties(properties);
    }
//
//    public static void main(String[] args) throws IOException {
//        try (XSSFWorkbook wb = new XSSFWorkbook()) {
//            XSSFSheet sheet = wb.createSheet("barchart");
//            final int NUM_OF_ROWS = 3;
//            final int NUM_OF_COLUMNS = 10;
//
//            // Create a row and put some cells in it. Rows are 0 based.
//            Row row;
//            Cell cell;
//            for (int rowIndex = 0; rowIndex < NUM_OF_ROWS; rowIndex++) {
//                row = sheet.createRow((short) rowIndex);
//                for (int colIndex = 0; colIndex < NUM_OF_COLUMNS; colIndex++) {
//                    cell = row.createCell((short) colIndex);
//                    cell.setCellValue(colIndex * (rowIndex + 1.0));
//                }
//            }
//
//            XSSFDrawing drawing = sheet.createDrawingPatriarch();
//            XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 5, 10, 15);
//
//            XSSFChart chart = drawing.createChart(anchor);
////            chart.setTitleText("x = 2x and x = 3x");
////            chart.setTitleOverlay(false);
////            XDDFChartLegend legend = chart.getOrAddLegend();
////            legend.setPosition(LegendPosition.TOP_RIGHT);
////
////            // Use a category axis for the bottom axis.
////            XSSFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
////            bottomAxis.setTitle("x"); // https://stackoverflow.com/questions/32010765
////            XSSFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
////            leftAxis.setTitle("f(x)");
////            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
////
////            XDDFDataSource<Double> xs = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(0, 0, 0, NUM_OF_COLUMNS - 1));
////            XDDFNumericalDataSource<Double> ys1 = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(1, 1, 0, NUM_OF_COLUMNS - 1));
////            XDDFNumericalDataSource<Double> ys2 = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(2, 2, 0, NUM_OF_COLUMNS - 1));
//
//            XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
//            XDDFChartData.Series series1 = data.addSeries(xs, ys1);
//            series1.setTitle("2x", null); // https://stackoverflow.com/questions/21855842
//            XDDFChartData.Series series2 = data.addSeries(xs, ys2);
//            series2.setTitle("3x", null);
//            chart.plot(data);
//
//            // in order to transform a bar chart into a column chart, you just need to change the bar direction
//            XDDFBarChartData bar = (XDDFBarChartData) data;
//            bar.setBarDirection(BarDirection.COL);
//            // looking for "Stacked Bar Chart"? uncomment the following line
//            // bar.setBarGrouping(BarGrouping.STACKED);
//
//            solidFillSeries(data, 0, PresetColor.CHARTREUSE);
//            solidFillSeries(data, 1, PresetColor.TURQUOISE);
//
//            // Write the output to a file
//            try (FileOutputStream fileOut = new FileOutputStream("ooxml-bar-chart.xlsx")) {
//                wb.write(fileOut);
//            }
//        }
//    }
//
//    private static void solidFillSeries(XDDFChartData data, int index, PresetColor color) {
//        XDDFSolidFillProperties fill = new XDDFSolidFillProperties(XDDFColor.from(color));
//        XDDFChartData.Series series = data.getSeries().get(index);
//        XDDFShapeProperties properties = series.getShapeProperties();
//        if (properties == null) {
//            properties = new XDDFShapeProperties();
//        }
//        properties.setFillProperties(fill);
//        series.setShapeProperties(properties);
//    }
    
    public static void barColumnChart() throws FileNotFoundException, IOException {
		try (XSSFWorkbook wb = new XSSFWorkbook()) {

			String sheetName = "CountryBarChart";//"CountryColumnChart";
			
			XSSFSheet sheet = wb.createSheet(sheetName);

			// Create row and put some cells in it. Rows and cells are 0 based.
			Row row = sheet.createRow((short) 0);

			Cell cell = row.createCell((short) 0);
			cell.setCellValue("Russia");

			cell = row.createCell((short) 1);
			cell.setCellValue("Canada");

			cell = row.createCell((short) 2);
			cell.setCellValue("USA");

			cell = row.createCell((short) 3);
			cell.setCellValue("China");

			cell = row.createCell((short) 4);
			cell.setCellValue("Brazil");

			cell = row.createCell((short) 5);
			cell.setCellValue("Australia");

			cell = row.createCell((short) 6);
			cell.setCellValue("India");

			row = sheet.createRow((short) 1);

			cell = row.createCell((short) 0);
			cell.setCellValue(17098242);

			cell = row.createCell((short) 1);
			cell.setCellValue(9984670);

			cell = row.createCell((short) 2);
			cell.setCellValue(9826675);

			cell = row.createCell((short) 3);
			cell.setCellValue(9596961);

			cell = row.createCell((short) 4);
			cell.setCellValue(8514877);

			cell = row.createCell((short) 5);
			cell.setCellValue(7741220);

			cell = row.createCell((short) 6);
			cell.setCellValue(3287263);

			XSSFDrawing drawing = sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 4, 7, 20);

			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText("Area-wise Top Seven Countries");
			chart.setTitleOverlay(false);

			XDDFChartLegend legend = chart.getOrAddLegend();
			legend.setPosition(LegendPosition.TOP_RIGHT);
			
			XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            bottomAxis.setTitle("Country");
            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            leftAxis.setTitle("Area");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

			XDDFDataSource<String> countries = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(0, 0, 0, 6));

			XDDFNumericalDataSource<Double> values = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, 1, 0, 6));
			
			XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
            XDDFChartData.Series series1 = data.addSeries(countries, values);
            series1.setTitle("Country", null);
			data.setVaryColors(true);
			chart.plot(data);
			
			// in order to transform a bar chart into a column chart, you just need to change the bar direction
            XDDFBarChartData bar = (XDDFBarChartData) data;
            bar.setBarDirection(BarDirection.BAR);
            //bar.setBarDirection(BarDirection.COL);

			// Write output to an excel file
            String filename = "D:\\\\test\\\\bar-chart-top-seven-countries.xlsx";//"column-chart-top-seven-countries.xlsx";
			try (FileOutputStream fileOut = new FileOutputStream(filename)) {
				wb.write(fileOut);
			}
		}
	}
}