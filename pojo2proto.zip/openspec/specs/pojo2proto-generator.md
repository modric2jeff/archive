---
name: pojo2proto-generator
description: POJO-to-Proto2 代码生成器 — 从 @RpcMapping 注解的 Java 方法生成 Proto2 文件
status: draft
---

# PoJo → Proto2 生成器设计

## 概述

实现一个将 Java 项目中带有 `@RpcMapping` 注解的 POJO 类转换为 Proto2 文件的生成器。支持单文件和每个类一个独立 proto 文件两种输出模式。

## 需求

1. 生成器接收两个参数：扫描的 package 名称、输出 proto 文件的路径
2. 识别方法的输入参数和返回参数，将对象类型和枚举类型转换为 proto2 的 message 和 enum
3. 特殊场景支持：
   - 继承关系 → 通过 Message Composition 保留
   - 内部类 → 转为独立的 message
   - 泛型 → 部分支持（List/Set/Map 原生映射，自定义泛型擦除）
   - 枚举 → 仅支持普通枚举，不支持嵌套

## 类型映射

| Java 类型 | Proto2 类型 | 说明 |
|-----------|-------------|------|
| `int` / `Integer` | `optional int32` | |
| `long` / `Long` | `optional int64` | |
| `float` / `Float` | `optional float` | |
| `double` / `Double` | `optional double` | |
| `boolean` / `Boolean` | `optional bool` | |
| `String` | `optional string` | |
| `byte[]` | `optional bytes` | |
| `void` | 无返回 / 不生成 response message | |
| `List<T>` / `Set<T>` / `Collection<T>` | `repeated T` | 解析泛型参数 |
| `Map<K,V>` | `map<K, V>` | 解析泛型参数 |
| `Optional<T>` | `optional T` | 拆箱 |
| `Date` / `LocalDateTime` | `optional int64` | 注释 `// timestamp millis` |
| 自定义对象 | `message` | 按类名生成 |
| 枚举 | `enum` | 顶层定义 |

## 继承关系处理

Proto2 使用 **Message Composition** 保留继承语义。

```java
// Java
class BaseEntity { Long id; Date createTime; }
class User extends BaseEntity { String name; int age; }
```

```protobuf
// Proto2
message BaseEntity {
    optional int64 id = 1;
    optional int64 createTime = 2;  // timestamp millis
}

message User {
    optional BaseEntity baseEntity = 1;  // 继承自 BaseEntity
    optional string name = 2;
    optional int32 age = 3;
}
```

规则：
- 子类 message 的首字段为父类类型，字段名 = 父类名首字母小写
- 通过注释 `// 继承自 <ParentClass>` 标记
- 多层继承链递归展开
- 所有字段使用 `optional` 关键字（proto2 风格）

## 内部类处理

每个内部类转换为独立的顶层 message，按简单类名命名。

```java
// Java 内部类
static class User { String name; int age; }
```

```protobuf
// 独立 message
message User {
    optional string name = 1;
    optional int32 age = 2;
}
```

## 泛型处理

| 场景 | 处理方式 |
|------|----------|
| `List<T>` / `Set<T>` | `repeated T` |
| `Map<K,V>` | `map<K, V>` |
| `Optional<T>` | `optional T` |
| 自定义泛型类（如 `Result<T>`） | 擦除为 `bytes` + 注释 `// generic type T` |
| 嵌套泛型（如 `List<Result<User>>`） | `repeated bytes` + 注释 |

## 枚举处理

枚举始终定义为顶层 enum（不嵌套在 message 内部）。

```protobuf
enum Status {
    ACTIVE = 0;
    INACTIVE = 1;
    DELETED = 2;
}
```

Proto2 枚举要求第一个值必须为 0。

## 组件架构

```
┌─────────────────────────────────────────────────┐
│               PojoToProtoGenerator               │  ← 入口
├─────────────────────────────────────────────────┤
│                                                   │
│  TypeAnalyzer ────── TypeResolver                │
│  (收集待转换的类型)   (继承/泛型/枚举/循环检测)     │
│                                                   │
│  ProtoFileGenerator                              │
│  (构建 proto AST → 渲染文本)                      │
│                                                   │
│  ProtoWriter ────── ProtoImportManager           │
│  (文件写入)           (多文件模式 import 管理)     │
│                                                   │
│  FieldNumberAllocator                            │
│  (字段编号分配)                                   │
└─────────────────────────────────────────────────┘
```

### 组件职责

**PojoToProtoGenerator** — 公开入口类
- 接收参数：`(String packageName, Path outputDir, boolean singleFile)`
- 调用 `RpcScanner` 获取方法列表
- 协调 `TypeAnalyzer` → `TypeResolver` → `ProtoFileGenerator` → `ProtoWriter` 流程

**TypeAnalyzer** — 类型收集
- 遍历方法的参数类型和返回类型
- 递归展开每个类型的字段类型，收集所有需转换的自定义类型
- 排除 JDK 内置类型（String、Number 子类等）

**TypeResolver** — 类型解析
- 解析继承链（DFS 遍历，检测循环继承）
- 解析泛型参数（从字段的 `ParameterizedType` 提取）
- 检测是否为枚举
- 检测循环引用（防止无限递归）

**ProtoFileGenerator** — 文件内容生成
- 接收已解析的类型集合
- 构建 proto AST（语法树）
- 渲染为 proto2 格式文本
- header：`syntax = "proto2";` + `package` + `option java_package`

**ProtoWriter** — 文件输出
- `singleFile=true` → 所有内容写入一个 `.proto` 文件
- `singleFile=false` → 每个 message/enum 写入独立文件，交由 `ProtoImportManager` 管理 import

**ProtoImportManager** — 多文件模式 import
- 跟踪哪些类型定义在哪些文件中
- 自动为跨文件引用生成 `import "xxx.proto";`

**FieldNumberAllocator** — 字段编号分配
- 为每个 message 的字段从 1 开始递增分配编号
- 为父类字段预留编号（通过追踪父类已用编号）

## 数据流

```
输入: (packageName, outputDir, singleFile)
        │
        ▼
RpcScanner.scan(packageName)
        │ 返回 List<RpcMethodInfo>
        ▼
TypeAnalyzer.collectTypes(methods)
        │ 返回 Set<Class<?>> (所有需转换的类型)
        ▼
TypeResolver.resolve(types)
        │ 返回 ResolvedType 图 (含继承、泛型、枚举信息)
        ▼
ProtoFileGenerator.generate(resolvedTypes)
        │ 返回 proto2 文本内容 (单文件) 或 Map<类名, 文本> (多文件)
        ▼
ProtoWriter.write(output)
        │
        ▼
输出: .proto 文件
```

## Java 文件结构

```
src/main/java/com/example/protogen/
├── PojoToProtoGenerator.java       # 入口
├── TypeAnalyzer.java               # 类型收集
├── TypeResolver.java               # 继承/泛型/枚举解析
├── ProtoFileGenerator.java         # proto AST → 文本
├── ProtoWriter.java                # 文件输出
├── ProtoImportManager.java         # 多文件 import 管理
└── FieldNumberAllocator.java       # 字段编号分配

src/test/java/com/example/protogen/
├── PojoToProtoGeneratorTest.java
├── TypeAnalyzerTest.java
├── TypeResolverTest.java
├── ProtoFileGeneratorTest.java
└── ProtoWriterTest.java
```

## 测试策略

| 测试类 | 测试内容 |
|--------|----------|
| `PojoToProtoGeneratorTest` | 端到端集成测试：给定 package，验证 proto 文件内容 |
| `TypeAnalyzerTest` | 收集类型正确性、排除 JDK 类型、递归展开 |
| `TypeResolverTest` | 继承链解析、泛型参数提取、循环引用检测、枚举检测 |
| `ProtoFileGeneratorTest` | proto2 语法正确性、字段编号分配、单文件/多文件输出 |
| `ProtoWriterTest` | 文件写入、import 生成、目录创建 |
