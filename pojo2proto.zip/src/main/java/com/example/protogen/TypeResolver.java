package com.example.protogen;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.*;

public class TypeResolver {

    private static final Map<Class<?>, String> PRIMITIVE_MAP = new LinkedHashMap<>();
    static {
        PRIMITIVE_MAP.put(int.class, "int32");
        PRIMITIVE_MAP.put(Integer.class, "int32");
        PRIMITIVE_MAP.put(long.class, "int64");
        PRIMITIVE_MAP.put(Long.class, "int64");
        PRIMITIVE_MAP.put(float.class, "float");
        PRIMITIVE_MAP.put(Float.class, "float");
        PRIMITIVE_MAP.put(double.class, "double");
        PRIMITIVE_MAP.put(Double.class, "double");
        PRIMITIVE_MAP.put(boolean.class, "bool");
        PRIMITIVE_MAP.put(Boolean.class, "bool");
        PRIMITIVE_MAP.put(String.class, "string");
        PRIMITIVE_MAP.put(byte[].class, "bytes");
        PRIMITIVE_MAP.put(Byte[].class, "bytes");
        PRIMITIVE_MAP.put(java.util.Date.class, "int64");
        PRIMITIVE_MAP.put(java.sql.Date.class, "int64");
        PRIMITIVE_MAP.put(java.time.LocalDateTime.class, "int64");
        PRIMITIVE_MAP.put(java.time.LocalDate.class, "int64");
    }

    private final Set<Class<?>> processed = new HashSet<>();

    public List<ResolvedType> resolve(Set<Class<?>> types) {
        processed.clear();
        List<ResolvedType> result = new ArrayList<>();

        // Topological sort: parent types before child types
        List<Class<?>> sorted = topologicalSort(types);
        for (Class<?> clazz : sorted) {
            if (!processed.contains(clazz)) {
                ResolvedType resolved = resolveType(clazz, types);
                if (resolved != null) {
                    result.add(resolved);
                }
            }
        }
        return result;
    }

    private ResolvedType resolveType(Class<?> clazz, Set<Class<?>> allTypes) {
        if (processed.contains(clazz)) return null;
        processed.add(clazz);

        if (clazz.isEnum()) {
            ResolvedType rt = new ResolvedType();
            rt.setClazz(clazz);
            rt.setMessageName(clazz.getSimpleName());
            rt.setEnum(true);
            for (Object constant : clazz.getEnumConstants()) {
                Enum<?> e = (Enum<?>) constant;
                rt.getEnumValues().add(e.name());
            }
            return rt;
        }

        ResolvedType rt = new ResolvedType();
        rt.setClazz(clazz);
        rt.setMessageName(clazz.getSimpleName());

        // Resolve inheritance: find parent class if it's in our type set
        Class<?> superclass = clazz.getSuperclass();
        if (superclass != null && superclass != Object.class
                && !TypeAnalyzer.isJdkType(superclass) && allTypes.contains(superclass)) {
            // Ensure parent is resolved first
            resolveType(superclass, allTypes);
            rt.setParentName(superclass.getSimpleName());
        }

        // Resolve fields
        int fieldIndex = 0;
        for (Field field : clazz.getDeclaredFields()) {
            if (Modifier.isStatic(field.getModifiers())) continue;
            if (Modifier.isTransient(field.getModifiers())) continue;

            ResolvedField rf = resolveField(field);
            if (rf != null) {
                rf.setFieldNumber(++fieldIndex);
                rt.getFields().add(rf);
            }
        }

        return rt;
    }

    private ResolvedField resolveField(Field field) {
        Type genericType = field.getGenericType();

        if (genericType instanceof TypeVariable) {
            TypeVariable<?> tv = (TypeVariable<?>) genericType;
            ResolvedField rf = new ResolvedField(field.getName(), "bytes");
            rf.setGenericType(true);
            rf.setGenericVarName(tv.getName());
            rf.setComment("generic type " + tv.getName());
            return rf;
        }

        if (genericType instanceof ParameterizedType) {
            ParameterizedType pt = (ParameterizedType) genericType;
            Class<?> rawType = (Class<?>) pt.getRawType();

            if (isListLike(rawType)) {
                Type arg = pt.getActualTypeArguments()[0];
                String elemType = toProtoType(arg);
                ResolvedField rf = new ResolvedField(field.getName(), elemType);
                rf.setRepeated(true);
                return rf;
            }

            if (isMapLike(rawType)) {
                Type keyArg = pt.getActualTypeArguments()[0];
                Type valArg = pt.getActualTypeArguments()[1];
                String keyType = toProtoType(keyArg);
                String valType = toProtoType(valArg);
                ResolvedField rf = new ResolvedField(field.getName(), valType);
                rf.setMap(true);
                rf.setMapKeyType(keyType);
                rf.setMapValueType(valType);
                return rf;
            }

            if (isOptional(rawType)) {
                Type arg = pt.getActualTypeArguments()[0];
                String innerType = toProtoType(arg);
                return new ResolvedField(field.getName(), innerType);
            }

            // Other parameterized types — generic fallback to bytes
            ResolvedField rf = new ResolvedField(field.getName(), "bytes");
            StringBuilder comment = new StringBuilder("generic <");
            for (int i = 0; i < pt.getActualTypeArguments().length; i++) {
                if (i > 0) comment.append(", ");
                comment.append(pt.getActualTypeArguments()[i].getTypeName());
            }
            comment.append(">");
            rf.setComment(comment.toString());
            return rf;
        }

        if (genericType instanceof Class) {
            Class<?> type = (Class<?>) genericType;
            String protoType = toProtoType(type);
            return new ResolvedField(field.getName(), protoType);
        }

        return null;
    }

    private String toProtoType(Type type) {
        if (type instanceof Class) {
            Class<?> clazz = (Class<?>) type;
            String mapped = PRIMITIVE_MAP.get(clazz);
            if (mapped != null) return mapped;
            if (TypeAnalyzer.isJdkType(clazz)) {
                return "bytes";
            }
            return clazz.getSimpleName();
        }
        if (type instanceof ParameterizedType) {
            return toProtoType(((ParameterizedType) type).getRawType());
        }
        if (type instanceof TypeVariable) {
            return "bytes";
        }
        return "bytes";
    }

    private String toProtoType(Class<?> type) {
        String mapped = PRIMITIVE_MAP.get(type);
        if (mapped != null) return mapped;
        if (TypeAnalyzer.isJdkType(type)) return "bytes";
        return type.getSimpleName();
    }

    private boolean isListLike(Class<?> clazz) {
        return List.class.isAssignableFrom(clazz)
                || Set.class.isAssignableFrom(clazz)
                || Collection.class.isAssignableFrom(clazz);
    }

    private boolean isMapLike(Class<?> clazz) {
        return Map.class.isAssignableFrom(clazz);
    }

    private boolean isOptional(Class<?> clazz) {
        return Optional.class == clazz;
    }

    private List<Class<?>> topologicalSort(Set<Class<?>> types) {
        List<Class<?>> sorted = new ArrayList<>();
        Set<Class<?>> visited = new HashSet<>();

        for (Class<?> type : types) {
            dfs(type, types, visited, sorted);
        }
        return sorted;
    }

    private void dfs(Class<?> type, Set<Class<?>> allTypes,
                     Set<Class<?>> visited, List<Class<?>> sorted) {
        if (visited.contains(type)) return;
        visited.add(type);

        Class<?> superclass = type.getSuperclass();
        if (superclass != null && superclass != Object.class
                && !TypeAnalyzer.isJdkType(superclass) && allTypes.contains(superclass)) {
            dfs(superclass, allTypes, visited, sorted);
        }

        sorted.add(type);
    }
}
