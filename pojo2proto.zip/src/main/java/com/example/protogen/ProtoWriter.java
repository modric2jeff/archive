package com.example.protogen;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class ProtoWriter {

    public void writeSingleFile(String content, Path outputPath) throws IOException {
        Files.createDirectories(outputPath.getParent());
        Files.writeString(outputPath, content);
    }

    public void writeMultiFile(Map<String, String> files, Path outputDir) throws IOException {
        Files.createDirectories(outputDir);
        for (Map.Entry<String, String> entry : files.entrySet()) {
            Path filePath = outputDir.resolve(entry.getKey());
            Files.writeString(filePath, entry.getValue());
        }
    }
}
