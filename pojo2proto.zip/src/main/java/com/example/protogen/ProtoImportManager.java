package com.example.protogen;

import java.util.*;

public class ProtoImportManager {

    private final Map<String, String> typeToFile = new HashMap<>();
    private final Map<String, Set<String>> fileReferences = new HashMap<>();

    public void registerDefinition(String typeName, String fileName) {
        typeToFile.put(typeName, fileName);
    }

    public void addReference(String sourceTypeName, String referencedTypeName) {
        String sourceFile = typeToFile.get(sourceTypeName);
        if (sourceFile == null) return;

        fileReferences.computeIfAbsent(sourceFile, k -> new LinkedHashSet<>())
                .add(referencedTypeName);
    }

    public Set<String> getImportsFor(String typeName) {
        String sourceFile = typeToFile.get(typeName);
        if (sourceFile == null) return Collections.emptySet();

        Set<String> imports = new LinkedHashSet<>();
        Set<String> refs = fileReferences.getOrDefault(sourceFile, Collections.emptySet());

        for (String ref : refs) {
            String refFile = typeToFile.get(ref);
            if (refFile != null && !refFile.equals(sourceFile)) {
                imports.add(refFile + ".proto");
            }
        }
        return imports;
    }

    public String getFileName(String typeName) {
        return typeToFile.get(typeName);
    }
}
