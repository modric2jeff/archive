package com.example.protogen;

import java.util.*;

public class ProtoFileGenerator {

    private final FieldNumberAllocator fieldNumberAllocator = new FieldNumberAllocator();

    public String generateSingleFile(List<ResolvedType> types, String javaPackage, String protoPackage) {
        StringBuilder sb = new StringBuilder();
        sb.append("syntax = \"proto2\";\n\n");
        sb.append("package ").append(protoPackage).append(";\n\n");
        sb.append("option java_package = \"").append(javaPackage).append("\";\n\n");

        for (ResolvedType type : types) {
            if (type.isEnum()) {
                generateEnum(sb, type);
            } else {
                generateMessage(sb, type);
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    private void generateMessage(StringBuilder sb, ResolvedType type) {
        if (type.getParentName() != null) {
            sb.append("// 继承自 ").append(type.getParentName()).append("\n");
        }
        sb.append("message ").append(type.getMessageName()).append(" {\n");

        fieldNumberAllocator.reset();

        // If has parent, first field references parent (composition for inheritance)
        if (type.getParentName() != null) {
            int num = fieldNumberAllocator.next();
            String parentField = toLowerCamel(type.getParentName());
            sb.append("  optional ").append(type.getParentName())
                    .append(" ").append(parentField)
                    .append(" = ").append(num).append(";  // 继承自 ")
                    .append(type.getParentName()).append("\n");
        }

        for (ResolvedField field : type.getFields()) {
            int num = fieldNumberAllocator.next();

            if (field.isMap()) {
                sb.append("  map<").append(field.getMapKeyType())
                        .append(", ").append(field.getMapValueType())
                        .append("> ").append(field.getName())
                        .append(" = ").append(num).append(";\n");
            } else if (field.isRepeated()) {
                sb.append("  repeated ").append(field.getProtoType())
                        .append(" ").append(field.getName())
                        .append(" = ").append(num).append(";\n");
            } else {
                sb.append("  optional ").append(field.getProtoType())
                        .append(" ").append(field.getName())
                        .append(" = ").append(num).append(";");
                if (field.isGenericType()) {
                    sb.append("  // generic type ").append(field.getGenericVarName());
                } else if (field.getComment() != null && !field.getComment().isEmpty()) {
                    sb.append("  // ").append(field.getComment());
                }
                sb.append("\n");
            }
        }

        sb.append("}\n");
    }

    private void generateEnum(StringBuilder sb, ResolvedType type) {
        sb.append("enum ").append(type.getMessageName()).append(" {\n");
        for (int i = 0; i < type.getEnumValues().size(); i++) {
            sb.append("  ").append(type.getEnumValues().get(i))
                    .append(" = ").append(i).append(";\n");
        }
        sb.append("}\n");
    }

    public Map<String, String> generateMultiFile(List<ResolvedType> types,
                                                   String javaPackage,
                                                   String protoPackage) {
        ProtoImportManager importMgr = new ProtoImportManager();

        // Register all type definitions (one file per type)
        for (ResolvedType type : types) {
            String fileName = type.getMessageName();
            importMgr.registerDefinition(type.getMessageName(), fileName);
        }

        // Register cross-references
        for (ResolvedType type : types) {
            if (type.getParentName() != null) {
                importMgr.addReference(type.getMessageName(), type.getParentName());
            }
            for (ResolvedField field : type.getFields()) {
                String refType = field.getProtoType();
                if (importMgr.getFileName(refType) != null
                        && !refType.equals(type.getMessageName())) {
                    importMgr.addReference(type.getMessageName(), refType);
                }
            }
        }

        // Generate one file per type
        Map<String, String> files = new LinkedHashMap<>();
        for (ResolvedType type : types) {
            StringBuilder sb = new StringBuilder();
            sb.append("syntax = \"proto2\";\n\n");
            sb.append("package ").append(protoPackage).append(";\n\n");
            sb.append("option java_package = \"").append(javaPackage).append("\";\n\n");

            // Add imports
            Set<String> imports = importMgr.getImportsFor(type.getMessageName());
            for (String imp : imports) {
                sb.append("import \"").append(imp).append("\";\n");
            }
            if (!imports.isEmpty()) {
                sb.append("\n");
            }

            // Generate the type
            if (type.isEnum()) {
                generateEnum(sb, type);
            } else {
                generateMessage(sb, type);
            }

            files.put(type.getMessageName() + ".proto", sb.toString().trim() + "\n");
        }

        return files;
    }

    static String toLowerCamel(String name) {
        if (name == null || name.isEmpty()) return name;
        return Character.toLowerCase(name.charAt(0)) + name.substring(1);
    }
}
