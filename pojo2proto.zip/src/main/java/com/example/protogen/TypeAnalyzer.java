package com.example.protogen;

import com.example.annotation.RpcMapping;
import org.reflections.Reflections;
import org.reflections.scanners.MethodAnnotationsScanner;
import org.reflections.scanners.SubTypesScanner;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;

public class TypeAnalyzer {

    private static final Set<String> JDK_PACKAGES = new HashSet<>(Arrays.asList(
            "java.lang", "java.util", "java.math", "java.time", "java.io"
    ));

    private final String packageName;

    public TypeAnalyzer(String packageName) {
        this.packageName = packageName;
    }

    public Set<Class<?>> collectTypes() {
        Reflections reflections = new Reflections(packageName,
                new MethodAnnotationsScanner(),
                new SubTypesScanner(false));

        Set<Method> methods = reflections.getMethodsAnnotatedWith(RpcMapping.class);
        Set<Class<?>> types = new LinkedHashSet<>();

        for (Method method : methods) {
            // Process parameter types
            for (java.lang.reflect.Parameter param : method.getParameters()) {
                collectType(param.getParameterizedType(), types, reflections);
            }
            // Process return type
            collectType(method.getGenericReturnType(), types, reflections);
        }

        return types;
    }

    private void collectType(Type type, Set<Class<?>> types, Reflections reflections) {
        if (type instanceof Class) {
            collectClass((Class<?>) type, types, reflections);
        } else if (type instanceof ParameterizedType) {
            ParameterizedType pt = (ParameterizedType) type;
            // Collect raw type
            collectClass((Class<?>) pt.getRawType(), types, reflections);
            // Collect type arguments
            for (Type arg : pt.getActualTypeArguments()) {
                collectType(arg, types, reflections);
            }
        }
        // TypeVariable and WildcardType are intentionally skipped
    }

    private void collectClass(Class<?> clazz, Set<Class<?>> types, Reflections reflections) {
        if (clazz.isPrimitive()) return;
        if (clazz.isArray()) {
            collectClass(clazz.getComponentType(), types, reflections);
            return;
        }
        if (isJdkType(clazz)) return;
        if (types.contains(clazz)) return;

        types.add(clazz);

        // Recurse into superclass
        Class<?> superclass = clazz.getSuperclass();
        if (superclass != null && superclass != Object.class && !isJdkType(superclass)) {
            collectClass(superclass, types, reflections);
        }

        // Recurse into declared fields
        for (Field field : clazz.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) continue;
            collectType(field.getGenericType(), types, reflections);
        }
    }

    static boolean isJdkType(Class<?> clazz) {
        if (clazz.isPrimitive()) return true;
        Package pkg = clazz.getPackage();
        if (pkg == null) return false;
        String pkgName = pkg.getName();
        for (String prefix : JDK_PACKAGES) {
            if (pkgName.startsWith(prefix)) return true;
        }
        return false;
    }
}
