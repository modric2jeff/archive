package com.example.protogen;

import java.util.ArrayList;
import java.util.List;

public class ResolvedType {
    private Class<?> clazz;
    private String messageName;
    private boolean isEnum;
    private List<String> enumValues = new ArrayList<>();
    private String parentName;
    private List<ResolvedField> fields = new ArrayList<>();
    private String comment;

    public Class<?> getClazz() { return clazz; }
    public void setClazz(Class<?> clazz) { this.clazz = clazz; }

    public String getMessageName() { return messageName; }
    public void setMessageName(String messageName) { this.messageName = messageName; }

    public boolean isEnum() { return isEnum; }
    public void setEnum(boolean anEnum) { isEnum = anEnum; }

    public List<String> getEnumValues() { return enumValues; }
    public void setEnumValues(List<String> enumValues) { this.enumValues = enumValues; }

    public String getParentName() { return parentName; }
    public void setParentName(String parentName) { this.parentName = parentName; }

    public List<ResolvedField> getFields() { return fields; }
    public void setFields(List<ResolvedField> fields) { this.fields = fields; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
}
