package com.example.protogen;

public class FieldNumberAllocator {
    private int current = 0;

    public int next() {
        return ++current;
    }

    public void reset() {
        current = 0;
    }
}
