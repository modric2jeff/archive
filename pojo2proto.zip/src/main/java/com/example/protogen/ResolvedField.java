package com.example.protogen;

public class ResolvedField {
    private String name;
    private String protoType;
    private boolean repeated;
    private boolean isMap;
    private String mapKeyType;
    private String mapValueType;
    private int fieldNumber;
    private String comment;
    private boolean genericType;
    private String genericVarName;

    public ResolvedField(String name, String protoType) {
        this.name = name;
        this.protoType = protoType;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getProtoType() { return protoType; }
    public void setProtoType(String protoType) { this.protoType = protoType; }

    public boolean isRepeated() { return repeated; }
    public void setRepeated(boolean repeated) { this.repeated = repeated; }

    public boolean isMap() { return isMap; }
    public void setMap(boolean map) { isMap = map; }

    public String getMapKeyType() { return mapKeyType; }
    public void setMapKeyType(String mapKeyType) { this.mapKeyType = mapKeyType; }

    public String getMapValueType() { return mapValueType; }
    public void setMapValueType(String mapValueType) { this.mapValueType = mapValueType; }

    public int getFieldNumber() { return fieldNumber; }
    public void setFieldNumber(int fieldNumber) { this.fieldNumber = fieldNumber; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public boolean isGenericType() { return genericType; }
    public void setGenericType(boolean genericType) { this.genericType = genericType; }

    public String getGenericVarName() { return genericVarName; }
    public void setGenericVarName(String genericVarName) { this.genericVarName = genericVarName; }
}
