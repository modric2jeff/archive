package com.example.protogen;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PojoToProtoGenerator {

    private final TypeResolver typeResolver;
    private final ProtoFileGenerator protoFileGenerator;
    private final ProtoWriter protoWriter;

    public PojoToProtoGenerator() {
        this.typeResolver = new TypeResolver();
        this.protoFileGenerator = new ProtoFileGenerator();
        this.protoWriter = new ProtoWriter();
    }

    /**
     * Generate proto2 file(s) from a package.
     *
     * @param packageName Java package to scan for @RpcMapping
     * @param outputPath If singleFile=true: path to output .proto file.
     *                   If singleFile=false: path to output directory.
     * @param singleFile true = one .proto file, false = one file per type
     */
    public void generate(String packageName, Path outputPath, boolean singleFile)
            throws IOException {

        TypeAnalyzer analyzer = new TypeAnalyzer(packageName);
        Set<Class<?>> rawTypes = analyzer.collectTypes();

        if (rawTypes.isEmpty()) {
            throw new IllegalArgumentException(
                    "No types found in package '" + packageName + "' with @RpcMapping methods");
        }

        List<ResolvedType> resolvedTypes = typeResolver.resolve(rawTypes);
        String javaPackage = deriveJavaPackage(resolvedTypes);

        if (singleFile) {
            String content = protoFileGenerator.generateSingleFile(
                    resolvedTypes, javaPackage, javaPackage);
            protoWriter.writeSingleFile(content, outputPath);
        } else {
            Map<String, String> files = protoFileGenerator.generateMultiFile(
                    resolvedTypes, javaPackage, javaPackage);
            protoWriter.writeMultiFile(files, outputPath);
        }
    }

    private String deriveJavaPackage(List<ResolvedType> types) {
        if (types.isEmpty()) return "unknown";
        Package pkg = types.get(0).getClazz().getPackage();
        return pkg != null ? pkg.getName() : "unknown";
    }
}
