package com.example;

import com.example.scanner.OpenApiConverter;
import com.example.scanner.RpcMethodInfo;
import com.example.scanner.RpcScanner;

import java.util.List;

/**
 * SpecDemo — 规范驱动的开发演示应用。
 * <p>
 * 启动时扫描当前包下所有 {@code @RpcMapping} 方法并输出 OpenAPI JSON。
 */
public class App {
    public static void main(String[] args) {
        RpcScanner scanner = new RpcScanner("com.example");
        List<RpcMethodInfo> methods = scanner.scan();

        System.out.println("Found " + methods.size() + " @RpcMapping methods.\n");

        String openApiJson = OpenApiConverter.convert(methods);
        System.out.println(openApiJson);
    }
}
