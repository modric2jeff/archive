package com.example.scanner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.*;

/**
 * 将 {@link RpcMethodInfo} 列表转换为 OpenAPI 3.0 JSON 文档。
 */
public class OpenApiConverter {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private OpenApiConverter() {
    }

    // Java 简单类型 → OpenAPI schema 映射表
    private static final Map<String, JsonNode> TYPE_MAP = new LinkedHashMap<>();

    static {
        TYPE_MAP.put("java.lang.String", schemaNode("string", null));
        TYPE_MAP.put("int", schemaNode("integer", "int32"));
        TYPE_MAP.put("java.lang.Integer", schemaNode("integer", "int32"));
        TYPE_MAP.put("long", schemaNode("integer", "int64"));
        TYPE_MAP.put("java.lang.Long", schemaNode("integer", "int64"));
        TYPE_MAP.put("double", schemaNode("number", "double"));
        TYPE_MAP.put("java.lang.Double", schemaNode("number", "double"));
        TYPE_MAP.put("float", schemaNode("number", "float"));
        TYPE_MAP.put("java.lang.Float", schemaNode("number", "float"));
        TYPE_MAP.put("boolean", schemaNode("boolean", null));
        TYPE_MAP.put("java.lang.Boolean", schemaNode("boolean", null));
        TYPE_MAP.put("void", null);
        TYPE_MAP.put("java.lang.Void", null);
    }

    private static JsonNode schemaNode(String type, String format) {
        ObjectNode node = MAPPER.createObjectNode();
        node.put("type", type);
        if (format != null) {
            node.put("format", format);
        }
        return node;
    }

    /**
     * 将扫描结果转换为完整的 OpenAPI 3.0 JSON 字符串。
     *
     * @param methods 扫描得到的方法列表
     * @param title   API 标题
     * @param version API 版本
     * @return 格式化后的 JSON 字符串
     */
    public static String convert(List<RpcMethodInfo> methods, String title, String version) {
        ObjectNode root = MAPPER.createObjectNode();
        root.put("openapi", "3.0.0");

        // info
        ObjectNode info = root.putObject("info");
        info.put("title", title != null ? title : "RPC API");
        info.put("version", version != null ? version : "1.0.0");

        // paths
        ObjectNode paths = root.putObject("paths");
        // 收集自定义类型用于 components/schemas
        Set<String> customTypes = new TreeSet<>();

        for (RpcMethodInfo method : methods) {
            String pathKey = method.getPath();
            if (pathKey == null || pathKey.isEmpty()) {
                pathKey = "/" + method.getMethodName();
            }

            ObjectNode pathItem = paths.has(pathKey)
                    ? (ObjectNode) paths.get(pathKey)
                    : paths.putObject(pathKey);

            String httpMethod = method.getHttpMethod().toLowerCase();
            ObjectNode operation = pathItem.putObject(httpMethod);

            operation.put("operationId", method.getMethodName());
            if (method.getSummary() != null && !method.getSummary().isEmpty()) {
                operation.put("summary", method.getSummary());
            }

            // parameters
            if (!method.getParameters().isEmpty()) {
                ArrayNode params = operation.putArray("parameters");
                for (RpcMethodInfo.ParamInfo param : method.getParameters()) {
                    ObjectNode paramNode = params.addObject();
                    paramNode.put("name", param.getName());
                    paramNode.put("in", "query");
                    paramNode.put("required", true);
                    paramNode.set("schema", resolveSchema(param.getType().getCanonicalName(), customTypes));
                }
            }

            // responses
            ObjectNode responses = operation.putObject("responses");
            ObjectNode response200 = responses.putObject("200");
            response200.put("description", "OK");

            String returnTypeName = method.getReturnType();
            JsonNode returnSchema = resolveSchema(returnTypeName, customTypes);
            if (returnSchema != null) {
                ObjectNode content = response200.putObject("content");
                ObjectNode jsonContent = content.putObject("application/json");
                jsonContent.set("schema", returnSchema);
            }
        }

        // components / schemas
        if (!customTypes.isEmpty()) {
            ObjectNode components = root.putObject("components");
            ObjectNode schemas = components.putObject("schemas");
            for (String type : customTypes) {
                String simpleName = type.substring(type.lastIndexOf('.') + 1);
                ObjectNode schema = schemas.putObject(simpleName);
                schema.put("type", "object");
                schema.put("description", type);
                schema.putObject("properties");
            }
        }

        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(root);
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize OpenAPI JSON", e);
        }
    }

    /**
     * 简化调用，使用默认标题和版本。
     */
    public static String convert(List<RpcMethodInfo> methods) {
        return convert(methods, "RPC API", "1.0.0");
    }

    /**
     * 根据 Java 类型全限定名解析 OpenAPI schema 节点。
     * 简单类型直接映射，自定义类型生成 $ref，void 返回 null。
     */
    private static JsonNode resolveSchema(String typeName, Set<String> customTypes) {
        // void → 无返回值，不生成 schema
        if ("void".equals(typeName) || "java.lang.Void".equals(typeName)) {
            return null;
        }

        JsonNode mapped = TYPE_MAP.get(typeName);
        if (mapped != null) {
            return mapped.deepCopy();
        }

        // 数组 / 集合类型 → array items
        if (typeName.startsWith("java.util.List<") || typeName.startsWith("java.util.Set<")
                || typeName.startsWith("java.util.Collection<")) {
            // 泛型擦除，简化处理
            ObjectNode arrayNode = MAPPER.createObjectNode();
            arrayNode.put("type", "array");
            arrayNode.set("items", MAPPER.createObjectNode().put("type", "object"));
            return arrayNode;
        }

        if (typeName.startsWith("[")) {
            ObjectNode arrayNode = MAPPER.createObjectNode();
            arrayNode.put("type", "array");
            String componentType = typeName.substring(1);
            JsonNode itemSchema = resolveSchema(componentType, customTypes);
            arrayNode.set("items", itemSchema != null ? itemSchema : MAPPER.createObjectNode().put("type", "object"));
            return arrayNode;
        }

        // 自定义类型 → $ref
        String simpleName = typeName.substring(typeName.lastIndexOf('.') + 1);
        customTypes.add(typeName);
        ObjectNode refNode = MAPPER.createObjectNode();
        refNode.put("$ref", "#/components/schemas/" + simpleName);
        return refNode;
    }
}
