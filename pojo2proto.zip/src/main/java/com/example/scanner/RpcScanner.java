package com.example.scanner;

import com.example.annotation.RpcMapping;
import org.reflections.Reflections;
import org.reflections.scanners.Scanners;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 扫描指定 package 下所有带有 {@code @RpcMapping} 注解的方法，
 * 提取方法元信息。
 */
public class RpcScanner {

    private final String packageName;

    public RpcScanner(String packageName) {
        this.packageName = packageName;
    }

    /**
     * 执行扫描，返回所有匹配方法的元信息列表。
     */
    public List<RpcMethodInfo> scan() {
        Reflections reflections = new Reflections(packageName, Scanners.MethodsAnnotated);

        Set<Method> annotatedMethods = reflections.getMethodsAnnotatedWith(RpcMapping.class);
        List<RpcMethodInfo> result = new ArrayList<>();

        for (Method method : annotatedMethods) {
            RpcMapping annotation = method.getAnnotation(RpcMapping.class);
            RpcMethodInfo info = new RpcMethodInfo(
                    method.getDeclaringClass().getCanonicalName(),
                    method.getName(),
                    annotation.path(),
                    annotation.method(),
                    annotation.summary(),
                    method.getParameters(),
                    method.getReturnType()
            );
            result.add(info);
        }

        return result;
    }
}
