package com.example.scanner;

import java.lang.reflect.Parameter;
import java.util.Arrays;
import java.util.List;

/**
 * 保存一个被 {@code @RpcMapping} 标记的方法的元信息。
 */
public class RpcMethodInfo {

    private final String className;
    private final String methodName;
    private final String path;
    private final String httpMethod;
    private final String summary;
    private final List<ParamInfo> parameters;
    private final String returnType;

    public RpcMethodInfo(String className, String methodName, String path,
                         String httpMethod, String summary,
                         Parameter[] parameters, Class<?> returnType) {
        this.className = className;
        this.methodName = methodName;
        this.path = path;
        this.httpMethod = httpMethod.toUpperCase();
        this.summary = summary;
        this.parameters = Arrays.stream(parameters)
                .map(p -> new ParamInfo(p.getName(), p.getType()))
                .toList();
        this.returnType = returnType.getCanonicalName();
    }

    public String getClassName() { return className; }
    public String getMethodName() { return methodName; }
    public String getPath() { return path; }
    public String getHttpMethod() { return httpMethod; }
    public String getSummary() { return summary; }
    public List<ParamInfo> getParameters() { return parameters; }
    public String getReturnType() { return returnType; }

    /** 单个参数信息 */
    public static class ParamInfo {
        private final String name;
        private final Class<?> type;

        public ParamInfo(String name, Class<?> type) {
            this.name = name;
            this.type = type;
        }

        public String getName() { return name; }
        public Class<?> getType() { return type; }
        public String getTypeSimpleName() { return type.getSimpleName(); }
    }
}
