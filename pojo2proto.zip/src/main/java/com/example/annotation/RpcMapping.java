package com.example.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标记一个方法为 RPC 端点，用于后续扫描并生成 OpenAPI 文档。
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RpcMapping {

    /** API 路径，例如 /user/get */
    String path() default "";

    /** HTTP 方法，默认 POST */
    String method() default "POST";

    /** 接口摘要描述 */
    String summary() default "";
}
