package com.example.service;

import com.example.annotation.RpcMapping;

/**
 * 用户服务 — 演示 {@code @RpcMapping} 注解的扫描。
 */
public class UserService {

    @RpcMapping(path = "/user/get", method = "GET", summary = "根据 ID 获取用户信息")
    public User getUser(String id) {
        return new User(id, "demo");
    }

    @RpcMapping(path = "/user/create", method = "POST", summary = "创建新用户")
    public boolean createUser(String name, int age) {
        return true;
    }

    @RpcMapping(path = "/user/delete", method = "DELETE", summary = "删除指定用户")
    public void deleteUser(Long id) {
    }

    @RpcMapping(path = "/user/list", method = "GET", summary = "获取用户列表")
    public java.util.List<User> listUsers(int page, int size) {
        return java.util.Collections.emptyList();
    }

    // 内部演示类
    public static class User {
        private String id;
        private String name;

        public User() {
        }

        public User(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
    }
}
