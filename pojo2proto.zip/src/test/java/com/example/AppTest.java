package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {
    @Test
    void appStarts() {
        assertTrue(true, "App should initialize without errors");
    }
}
