package com.example.protogen;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoImportManagerTest {

    @Test
    void shouldManageImportForTypeInDifferentFile() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("BaseEntity", "BaseEntity");
        mgr.registerDefinition("InheritedUser", "InheritedUser");
        mgr.addReference("InheritedUser", "BaseEntity");

        Set<String> imports = mgr.getImportsFor("InheritedUser");
        assertEquals(1, imports.size(), "Should have one import");
        assertTrue(imports.contains("BaseEntity.proto"),
                "Should import BaseEntity.proto");
    }

    @Test
    void shouldNotImportTypesInSameFile() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("User", "User");
        mgr.addReference("User", "Order");
        // Register Order in same file as User
        mgr.registerDefinition("Order", "User");

        Set<String> imports = mgr.getImportsFor("User");
        assertTrue(imports.isEmpty(), "No import needed if both in same file");
    }

    @Test
    void shouldHandleNoReferences() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("Standalone", "Standalone");
        Set<String> imports = mgr.getImportsFor("Standalone");
        assertTrue(imports.isEmpty(), "Standalone type should have no imports");
    }

    @Test
    void shouldReturnFileName() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("User", "User");
        assertEquals("User", mgr.getFileName("User"));
        assertNull(mgr.getFileName("Unknown"));
    }
}
