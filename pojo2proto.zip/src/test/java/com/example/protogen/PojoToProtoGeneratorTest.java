package com.example.protogen;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class PojoToProtoGeneratorTest {

    @TempDir
    Path tempDir;

    @Test
    void shouldGenerateSingleFileIntegration() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("all.proto");

        generator.generate(
                "com.example.protogen.testservice",
                outputPath,
                true  // single file
        );

        assertTrue(Files.exists(outputPath), "Output file should exist");
        String content = Files.readString(outputPath);
        assertTrue(content.contains("syntax = \"proto2\";"));
        assertTrue(content.contains("message User {"));
        assertTrue(content.contains("optional string name = 1;"));
        assertTrue(content.contains("optional int32 age = 2;"));
    }

    @Test
    void shouldGenerateMultiFileIntegration() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputDir = tempDir.resolve("proto");

        generator.generate(
                "com.example.protogen.testservice",
                outputDir,
                false  // multi-file
        );

        assertTrue(Files.exists(outputDir.resolve("BaseEntity.proto")));
        assertTrue(Files.exists(outputDir.resolve("InheritedUser.proto")));
        assertTrue(Files.exists(outputDir.resolve("AdminUser.proto")));

        String inheritedUserContent = Files.readString(outputDir.resolve("InheritedUser.proto"));
        assertTrue(inheritedUserContent.contains("import \"BaseEntity.proto\";"));
        assertTrue(inheritedUserContent.contains("// 继承自 BaseEntity"));
    }

    @Test
    void shouldGenerateAllFeaturesCombined() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("combined.proto");

        generator.generate(
                "com.example.protogen.testservice",
                outputPath,
                true
        );

        String content = Files.readString(outputPath);
        // Should contain all features
        assertTrue(content.contains("message User {"));
        assertTrue(content.contains("message BaseEntity {"));
        assertTrue(content.contains("enum UserStatus {"));
        assertTrue(content.contains("message Result {"));
        assertTrue(content.contains("message Order {"));
        assertTrue(content.contains("message OrderItem {"));
    }

    @Test
    void shouldThrowExceptionForEmptyPackage() {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("empty.proto");

        assertThrows(IllegalArgumentException.class, () -> {
            generator.generate("com.example.nonexistent", outputPath, true);
        }, "Should throw if no @RpcMapping methods found");
    }
}
