package com.example.protogen;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoFileGeneratorTest {

    private TypeAnalyzer analyzer;
    private TypeResolver resolver;
    private ProtoFileGenerator generator;

    @BeforeEach
    void setUp() {
        analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        resolver = new TypeResolver();
        generator = new ProtoFileGenerator();
    }

    @Test
    void shouldGenerateValidProto2Header() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example.protogen", "com.example.protogen");

        assertTrue(output.startsWith("syntax = \"proto2\";"),
                "Should start with proto2 syntax declaration");
        assertTrue(output.contains("package com.example.protogen;"),
                "Should contain package declaration");
    }

    @Test
    void shouldGenerateMessageForSimpleType() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message User {"), "Should generate User message");
        assertTrue(output.contains("optional string name = 1;"), "Should have name field");
        assertTrue(output.contains("optional int32 age = 2;"), "Should have age field");
    }

    @Test
    void shouldGenerateInheritanceWithComposition() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message BaseEntity {"));
        assertTrue(output.contains("message InheritedUser {"));
        assertTrue(output.contains("// 继承自 BaseEntity"),
                "Should have inheritance comment");
        assertTrue(output.contains("optional BaseEntity baseEntity = 1;"),
                "Parent field should be field 1");
    }

    @Test
    void shouldGenerateEnum() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("enum UserStatus {"), "Should generate UserStatus enum");
        assertTrue(output.contains("ACTIVE = 0;"), "Enum values should start at 0");
        assertTrue(output.contains("INACTIVE = 1;"));
        assertTrue(output.contains("SUSPENDED = 2;"));
    }

    @Test
    void shouldGenerateGenericTypeAsBytes() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message Result {"));
        assertTrue(output.contains("optional bytes data = 3;"),
                "Generic field should be bytes");
    }

    @Test
    void shouldGenerateInnerClassesAsSeparateMessages() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message Order {"), "Should generate Order message");
        assertTrue(output.contains("message OrderItem {"), "Should generate OrderItem message");
    }

    @Test
    void shouldHandleEmptyTypes() {
        String output = generator.generateSingleFile(Collections.emptyList(), "com.example", "com.example");
        assertTrue(output.contains("syntax = \"proto2\";"),
                "Empty list should still produce valid header");
    }

    @Test
    void shouldGenerateMultiFileOutput() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        Map<String, String> files = generator.generateMultiFile(resolved, "com.example.protogen", "com.example.protogen");

        assertTrue(files.containsKey("BaseEntity.proto"), "Should generate BaseEntity.proto");
        assertTrue(files.containsKey("InheritedUser.proto"), "Should generate InheritedUser.proto");
        assertTrue(files.containsKey("AdminUser.proto"), "Should generate AdminUser.proto");
        assertTrue(files.containsKey("User.proto"), "Should generate User.proto");
        assertTrue(files.containsKey("UserStatus.proto"), "Should generate UserStatus.proto");
    }

    @Test
    void multiFileShouldContainImportForParentType() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        Map<String, String> files = generator.generateMultiFile(resolved, "com.example.protogen", "com.example.protogen");

        String inheritedUserContent = files.get("InheritedUser.proto");
        assertNotNull(inheritedUserContent);
        assertTrue(inheritedUserContent.contains("import \"BaseEntity.proto\";"),
                "InheritedUser.proto should import BaseEntity.proto");

        String adminContent = files.get("AdminUser.proto");
        assertNotNull(adminContent);
        assertTrue(adminContent.contains("import \"InheritedUser.proto\";"),
                "AdminUser.proto should import InheritedUser.proto");
    }
}
