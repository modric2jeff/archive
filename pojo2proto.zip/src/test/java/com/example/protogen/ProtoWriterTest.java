package com.example.protogen;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoWriterTest {

    @TempDir
    Path tempDir;

    @Test
    void shouldWriteSingleFile() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        String content = "syntax = \"proto2\";\n\nmessage Test {}\n";
        Path outputPath = tempDir.resolve("output.proto");

        writer.writeSingleFile(content, outputPath);

        assertTrue(Files.exists(outputPath), "File should exist");
        String written = Files.readString(outputPath);
        assertEquals(content, written, "Content should match");
    }

    @Test
    void shouldWriteMultipleFiles() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        Map<String, String> files = new LinkedHashMap<>();
        files.put("Test1.proto", "message Test1 {}");
        files.put("Test2.proto", "message Test2 {}");
        Path outputDir = tempDir.resolve("proto");

        writer.writeMultiFile(files, outputDir);

        assertTrue(Files.exists(outputDir.resolve("Test1.proto")), "Test1.proto should exist");
        assertTrue(Files.exists(outputDir.resolve("Test2.proto")), "Test2.proto should exist");
        assertEquals("message Test1 {}", Files.readString(outputDir.resolve("Test1.proto")));
    }

    @Test
    void shouldCreateOutputDirectoryIfNotExists() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        Path deepDir = tempDir.resolve("a").resolve("b").resolve("c");
        writer.writeSingleFile("content", deepDir.resolve("test.proto"));

        assertTrue(Files.exists(deepDir), "Directory should be created");
        assertTrue(Files.exists(deepDir.resolve("test.proto")));
    }
}
