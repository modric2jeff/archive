package com.example.protogen;

import com.example.protogen.testservice.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class TypeResolverTest {

    private TypeAnalyzer analyzer;
    private TypeResolver resolver;

    @BeforeEach
    void setUp() {
        analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        resolver = new TypeResolver();
    }

    @Test
    void shouldResolveSimpleType() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType userType = resolved.stream()
                .filter(t -> t.getMessageName().equals("User"))
                .findFirst().orElse(null);
        assertNotNull(userType, "User type should be resolved");
        assertFalse(userType.isEnum(), "User should not be enum");
        assertNull(userType.getParentName(), "SimpleService.User has no parent");
        assertEquals(2, userType.getFields().size(), "User should have 2 fields");
    }

    @Test
    void shouldResolveInheritanceChain() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType baseEntity = resolved.stream()
                .filter(t -> t.getMessageName().equals("BaseEntity"))
                .findFirst().orElse(null);
        assertNotNull(baseEntity);
        assertNull(baseEntity.getParentName(), "BaseEntity has no parent");

        ResolvedType inheritedUser = resolved.stream()
                .filter(t -> t.getMessageName().equals("InheritedUser"))
                .findFirst().orElse(null);
        assertNotNull(inheritedUser);
        assertEquals("BaseEntity", inheritedUser.getParentName(),
                "InheritedUser should extend BaseEntity");

        // AdminUser extends InheritedUser extends BaseEntity
        ResolvedType adminUser = resolved.stream()
                .filter(t -> t.getMessageName().equals("AdminUser"))
                .findFirst().orElse(null);
        assertNotNull(adminUser);
        assertEquals("InheritedUser", adminUser.getParentName(),
                "AdminUser should extend InheritedUser");
    }

    @Test
    void shouldResolveEnum() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType statusEnum = resolved.stream()
                .filter(t -> t.getMessageName().equals("UserStatus"))
                .findFirst().orElse(null);
        assertNotNull(statusEnum, "UserStatus enum should be resolved");
        assertTrue(statusEnum.isEnum(), "UserStatus should be enum");
        assertTrue(statusEnum.getEnumValues().contains("ACTIVE"), "Should contain ACTIVE");
        assertTrue(statusEnum.getEnumValues().contains("INACTIVE"), "Should contain INACTIVE");
        assertTrue(statusEnum.getEnumValues().contains("SUSPENDED"), "Should contain SUSPENDED");
    }

    @Test
    void shouldResolveGenericType() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType resultType = resolved.stream()
                .filter(t -> t.getMessageName().equals("Result"))
                .findFirst().orElse(null);
        assertNotNull(resultType, "Result generic type should be resolved");

        // data field with generic type T should be marked as generic
        ResolvedField dataField = resultType.getFields().stream()
                .filter(f -> f.getName().equals("data"))
                .findFirst().orElse(null);
        assertNotNull(dataField, "data field should exist");
        assertTrue(dataField.isGenericType(), "data field should be generic");
        assertEquals("bytes", dataField.getProtoType(), "Generic field proto type should be bytes");
        assertEquals("T", dataField.getGenericVarName(), "Generic var name should be T");
    }

    @Test
    void shouldHandleComplexTypesWithoutException() {
        Set<Class<?>> types = analyzer.collectTypes();
        assertDoesNotThrow(() -> resolver.resolve(types),
                "Should handle all types without exception");
    }
}
