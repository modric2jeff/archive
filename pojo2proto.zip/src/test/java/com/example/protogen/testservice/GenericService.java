package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;
import java.util.List;
import java.util.Map;

public class GenericService {

    @RpcMapping(path = "/generic/result", method = "GET")
    public Result<SimpleService.User> getResult() {
        return null;
    }

    @RpcMapping(path = "/generic/list", method = "GET")
    public List<SimpleService.User> listUsers() {
        return null;
    }

    @RpcMapping(path = "/generic/map", method = "GET")
    public Map<String, SimpleService.User> getUserMap() {
        return null;
    }
}

class Result<T> {
    private int code;
    private String message;
    private T data;

    public int getCode() { return code; }
    public void setCode(int code) { this.code = code; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public T getData() { return data; }
    public void setData(T data) { this.data = data; }
}
