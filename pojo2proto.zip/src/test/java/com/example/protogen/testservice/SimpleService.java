package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class SimpleService {

    @RpcMapping(path = "/simple/get", method = "GET", summary = "Get a user")
    public User getUser(Long id) {
        return null;
    }

    @RpcMapping(path = "/simple/create", method = "POST")
    public boolean createUser(String name, int age) {
        return false;
    }

    public static class User {
        private String name;
        private int age;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public int getAge() { return age; }
        public void setAge(int age) { this.age = age; }
    }
}
