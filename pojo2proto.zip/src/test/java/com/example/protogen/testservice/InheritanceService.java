package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;
import java.util.Date;

public class InheritanceService {

    @RpcMapping(path = "/inheritance/user", method = "GET")
    public InheritedUser getInheritedUser(Long id) {
        return null;
    }

    @RpcMapping(path = "/inheritance/admin", method = "GET")
    public AdminUser getAdminUser(Long id) {
        return null;
    }
}

class BaseEntity {
    private Long id;
    private Date createTime;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date createTime) { this.createTime = createTime; }
}

class InheritedUser extends BaseEntity {
    private String name;
    private int age;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}

class AdminUser extends InheritedUser {
    private String role;
    private int level;

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
}
