package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class EnumService {

    @RpcMapping(path = "/enum/status", method = "GET")
    public UserStatus getStatus(Long id) {
        return null;
    }
}

enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
