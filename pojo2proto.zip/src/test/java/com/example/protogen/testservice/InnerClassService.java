package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class InnerClassService {

    @RpcMapping(path = "/inner/order", method = "GET")
    public Order getOrder(Long id) {
        return null;
    }

    public static class Order {
        private String orderId;
        private OrderItem item;

        public String getOrderId() { return orderId; }
        public void setOrderId(String orderId) { this.orderId = orderId; }
        public OrderItem getItem() { return item; }
        public void setItem(OrderItem item) { this.item = item; }
    }

    public static class OrderItem {
        private String productId;
        private int quantity;

        public String getProductId() { return productId; }
        public void setProductId(String productId) { this.productId = productId; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
    }
}
