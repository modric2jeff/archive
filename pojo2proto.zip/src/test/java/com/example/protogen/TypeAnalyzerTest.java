package com.example.protogen;

import org.junit.jupiter.api.Test;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class TypeAnalyzerTest {

    @Test
    void shouldCollectTypesFromPackage() {
        TypeAnalyzer analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        Set<Class<?>> types = analyzer.collectTypes();

        // SimpleService.User should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("User")),
                "Should collect User type from SimpleService");
        // BaseEntity should be found (parent of InheritedUser)
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("BaseEntity")),
                "Should collect BaseEntity type from inheritance chain");
        // InheritedUser should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("InheritedUser")),
                "Should collect InheritedUser type");
        // AdminUser should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("AdminUser")),
                "Should collect AdminUser type");
        // UserStatus enum should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("UserStatus")),
                "Should collect UserStatus enum type");
        // Generic Result type should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("Result")),
                "Should collect Result generic type");
        // Inner classes should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("Order")),
                "Should collect Order inner class");
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("OrderItem")),
                "Should collect OrderItem inner class");
    }

    @Test
    void shouldNotCollectJdkTypes() {
        TypeAnalyzer analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        Set<Class<?>> types = analyzer.collectTypes();

        assertFalse(types.stream().anyMatch(t -> t == String.class),
                "Should not collect String");
        assertFalse(types.stream().anyMatch(t -> t == Long.class),
                "Should not collect Long");
        assertFalse(types.stream().anyMatch(t -> t == Integer.class),
                "Should not collect Integer");
    }

    @Test
    void shouldReturnEmptyForPackageWithNoRpcMapping() {
        TypeAnalyzer analyzer = new TypeAnalyzer("java.lang");
        Set<Class<?>> types = analyzer.collectTypes();
        assertTrue(types.isEmpty(), "Should return empty set for package with no @RpcMapping");
    }
}
