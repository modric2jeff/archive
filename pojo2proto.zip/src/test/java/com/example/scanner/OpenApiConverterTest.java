package com.example.scanner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.annotation.RpcMapping;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OpenApiConverterTest {

    private static List<RpcMethodInfo> methods;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @BeforeAll
    static void setup() {
        RpcScanner scanner = new RpcScanner("com.example.service");
        methods = scanner.scan();
    }

    @Test
    void shouldOutputValidJson() throws Exception {
        String json = OpenApiConverter.convert(methods);
        assertNotNull(json);

        JsonNode root = MAPPER.readTree(json);
        assertEquals("3.0.0", root.get("openapi").asText());
        assertEquals("RPC API", root.get("info").get("title").asText());
    }

    @Test
    void shouldContainAllPaths() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);
        JsonNode paths = root.get("paths");

        assertTrue(paths.has("/user/get"));
        assertTrue(paths.has("/user/create"));
        assertTrue(paths.has("/user/delete"));
        assertTrue(paths.has("/user/list"));
    }

    @Test
    void shouldHaveCorrectHttpMethods() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);
        JsonNode paths = root.get("paths");

        assertTrue(paths.get("/user/get").has("get"));
        assertTrue(paths.get("/user/create").has("post"));
        assertTrue(paths.get("/user/delete").has("delete"));
        assertTrue(paths.get("/user/list").has("get"));
    }

    @Test
    void shouldIncludeParameters() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);

        JsonNode createUser = root.get("paths").get("/user/create").get("post");
        assertTrue(createUser.has("parameters"));
        assertEquals(2, createUser.get("parameters").size());

        assertEquals("name", createUser.get("parameters").get(0).get("name").asText());
        assertEquals("age", createUser.get("parameters").get(1).get("name").asText());
    }

    @Test
    void shouldMapParameterTypes() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);

        JsonNode params = root.get("paths").get("/user/create").get("post").get("parameters");

        // name: String → type: string
        assertEquals("string", params.get(0).get("schema").get("type").asText());

        // age: int → type: integer, format: int32
        assertEquals("integer", params.get(1).get("schema").get("type").asText());
        assertEquals("int32", params.get(1).get("schema").get("format").asText());
    }

    @Test
    void shouldGenerateRefForCustomReturnType() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);

        JsonNode getUser = root.get("paths").get("/user/get").get("get");
        JsonNode responseSchema = getUser.get("responses").get("200")
                .get("content").get("application/json").get("schema");

        assertTrue(responseSchema.has("$ref"));
        assertEquals("#/components/schemas/User", responseSchema.get("$ref").asText());
    }

    @Test
    void shouldGenerateComponentsSchemasForCustomTypes() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);

        JsonNode schemas = root.get("components").get("schemas");
        assertTrue(schemas.has("User"));
        assertEquals("object", schemas.get("User").get("type").asText());
    }

    @Test
    void shouldHandleVoidReturnType() throws Exception {
        String json = OpenApiConverter.convert(methods);
        JsonNode root = MAPPER.readTree(json);

        JsonNode deleteUser = root.get("paths").get("/user/delete").get("delete");
        assertFalse(deleteUser.get("responses").get("200").has("content"),
                "void method should not have response content");
    }

    @Test
    void shouldHandleEmptyList() throws Exception {
        String json = OpenApiConverter.convert(List.of());
        JsonNode root = MAPPER.readTree(json);
        assertTrue(root.get("paths").isEmpty());
    }
}
