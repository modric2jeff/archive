package com.example.scanner;

import com.example.service.UserService;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RpcScannerTest {

    @Test
    void shouldScanRpcMappingMethods() {
        RpcScanner scanner = new RpcScanner("com.example.service");
        List<RpcMethodInfo> methods = scanner.scan();

        assertNotNull(methods);
        assertEquals(4, methods.size(), "UserService has 4 @RpcMapping methods");
    }

    @Test
    void shouldContainAllServiceMethods() {
        RpcScanner scanner = new RpcScanner("com.example.service");
        List<RpcMethodInfo> methods = scanner.scan();

        var methodNames = methods.stream().map(RpcMethodInfo::getMethodName).toList();
        assertTrue(methodNames.contains("getUser"));
        assertTrue(methodNames.contains("createUser"));
        assertTrue(methodNames.contains("deleteUser"));
        assertTrue(methodNames.contains("listUsers"));
    }

    @Test
    void shouldExtractParameterNames() {
        RpcScanner scanner = new RpcScanner("com.example.service");
        List<RpcMethodInfo> methods = scanner.scan();

        var createUser = methods.stream()
                .filter(m -> m.getMethodName().equals("createUser"))
                .findFirst()
                .orElseThrow();

        assertEquals(2, createUser.getParameters().size());
        assertEquals("name", createUser.getParameters().get(0).getName());
        assertEquals("age", createUser.getParameters().get(1).getName());
    }

    @Test
    void shouldExtractHttpMethodAndPath() {
        RpcScanner scanner = new RpcScanner("com.example.service");
        List<RpcMethodInfo> methods = scanner.scan();

        var getUser = methods.stream()
                .filter(m -> m.getMethodName().equals("getUser"))
                .findFirst()
                .orElseThrow();

        assertEquals("GET", getUser.getHttpMethod());
        assertEquals("/user/get", getUser.getPath());
    }

    @Test
    void shouldReturnEmptyWhenNoAnnotatedMethods() {
        RpcScanner scanner = new RpcScanner("com.example.scanner");
        List<RpcMethodInfo> methods = scanner.scan();

        // scanner package has no @RpcMapping methods
        assertTrue(methods.isEmpty());
    }
}
