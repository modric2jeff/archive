# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A spec-driven development workspace using **openspec** — specifications drive implementation. The workflow is: spec → propose → apply → archive.

## Key Commands

### Workflow
- **Explore codebase/specs**: `/opsx-explore` — scan specs and code to understand context before proposing changes
- **Propose a change**: `/opsx-propose` — create a new change proposal from a spec
- **Apply a change**: `/opsx-apply` — implement an approved proposal
- **Archive a change**: `/opsx-archive` — mark a completed change as archived

### Build
```bash
mvn clean install                           # Full build
mvn test                                    # Run all tests
mvn test -Dtest=AppTest                     # Run a single test class
```

## Project Structure

```
├── .opencode/
│   ├── command/          # Slash commands (opsx-*)
│   └── skills/           # Implementation skills for the workflow
├── openspec/
│   ├── config.yaml       # Spec-driven development config
│   ├── specs/            # Feature/component specifications
│   └── changes/          # Change proposals and archives
├── pom.xml               # Maven project descriptor
└── src/                  # Source code
```

## Workflow Culture

This project follows a **spec-first** approach:
1. **Specs** (`openspec/specs/`) define what needs to be built — requirements, design decisions, acceptance criteria.
2. **Changes** (`openspec/changes/`) track the lifecycle of implementing a spec — from proposal through review to archive.
3. No code is written without a corresponding spec or approved change proposal.

## Tech Stack

- Java (via Maven)
- Additional stack to be defined in openspec/config.yaml context
