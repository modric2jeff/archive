# PoJo → Proto2 Generator Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a code generator that scans `@RpcMapping`-annotated methods and converts their POJO parameter/return types into Proto2 `.proto` files.

**Architecture:** Modular pipeline — `TypeAnalyzer` collects custom types from the scanned package, `TypeResolver` resolves inheritance/generics/enums/cycles, `ProtoFileGenerator` renders [proto2 text](openspec/specs/pojo2proto-generator.md) with Message Composition for inheritance. Supports single-file and multi-file output modes.

**Tech Stack:** Java 17, Maven, reflections 0.10.2 (already in project), JUnit 5, Proto2 syntax

---

### Task 1: Create test fixture classes

**Files:**
- Create: `src/test/java/com/example/protogen/testservice/SimpleService.java`
- Create: `src/test/java/com/example/protogen/testservice/InheritanceService.java`
- Create: `src/test/java/com/example/protogen/testservice/EnumService.java`
- Create: `src/test/java/com/example/protogen/testservice/GenericService.java`
- Create: `src/test/java/com/example/protogen/testservice/InnerClassService.java`

- [ ] **Step 1: Create SimpleService**

```java
package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class SimpleService {

    @RpcMapping(path = "/simple/get", method = "GET", summary = "Get a user")
    public User getUser(Long id) {
        return null;
    }

    @RpcMapping(path = "/simple/create", method = "POST")
    public boolean createUser(String name, int age) {
        return false;
    }

    public static class User {
        private String name;
        private int age;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public int getAge() { return age; }
        public void setAge(int age) { this.age = age; }
    }
}
```

- [ ] **Step 2: Create InheritanceService**

```java
package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;
import java.util.Date;

public class InheritanceService {

    @RpcMapping(path = "/inheritance/user", method = "GET")
    public InheritedUser getInheritedUser(Long id) {
        return null;
    }

    @RpcMapping(path = "/inheritance/admin", method = "GET")
    public AdminUser getAdminUser(Long id) {
        return null;
    }
}

class BaseEntity {
    private Long id;
    private Date createTime;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date createTime) { this.createTime = createTime; }
}

class InheritedUser extends BaseEntity {
    private String name;
    private int age;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}

class AdminUser extends InheritedUser {
    private String role;
    private int level;

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
}
```

- [ ] **Step 3: Create EnumService**

```java
package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class EnumService {

    @RpcMapping(path = "/enum/status", method = "GET")
    public UserStatus getStatus(Long id) {
        return null;
    }
}

enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
```

- [ ] **Step 4: Create GenericService**

```java
package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;
import java.util.List;
import java.util.Map;

public class GenericService {

    @RpcMapping(path = "/generic/result", method = "GET")
    public Result<SimpleService.User> getResult() {
        return null;
    }

    @RpcMapping(path = "/generic/list", method = "GET")
    public List<SimpleService.User> listUsers() {
        return null;
    }

    @RpcMapping(path = "/generic/map", method = "GET")
    public Map<String, SimpleService.User> getUserMap() {
        return null;
    }
}

class Result<T> {
    private int code;
    private String message;
    private T data;

    public int getCode() { return code; }
    public void setCode(int code) { this.code = code; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public T getData() { return data; }
    public void setData(T data) { this.data = data; }
}
```

- [ ] **Step 5: Create InnerClassService**

```java
package com.example.protogen.testservice;

import com.example.annotation.RpcMapping;

public class InnerClassService {

    @RpcMapping(path = "/inner/order", method = "GET")
    public Order getOrder(Long id) {
        return null;
    }

    public static class Order {
        private String orderId;
        private OrderItem item;

        public String getOrderId() { return orderId; }
        public void setOrderId(String orderId) { this.orderId = orderId; }
        public OrderItem getItem() { return item; }
        public void setItem(OrderItem item) { this.item = item; }
    }

    public static class OrderItem {
        private String productId;
        private int quantity;

        public String getProductId() { return productId; }
        public void setProductId(String productId) { this.productId = productId; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
    }
}
```

- [ ] **Step 6: Verify compilation**

```bash
cd d:\workspace\specdemo && mvn test-compile
```
Expected: BUILD SUCCESS

---

### Task 2: TypeAnalyzer — collect custom types from scanned package

**Files:**
- Create: `src/main/java/com/example/protogen/TypeAnalyzer.java`
- Create: `src/test/java/com/example/protogen/TypeAnalyzerTest.java`

- [ ] **Step 1: Write TypeAnalyzerTest**

```java
package com.example.protogen;

import org.junit.jupiter.api.Test;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class TypeAnalyzerTest {

    @Test
    void shouldCollectTypesFromPackage() {
        TypeAnalyzer analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        Set<Class<?>> types = analyzer.collectTypes();

        // SimpleService.User should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("User")),
                "Should collect User type from SimpleService");
        // BaseEntity should be found (parent of InheritedUser)
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("BaseEntity")),
                "Should collect BaseEntity type from inheritance chain");
        // InheritedUser should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("InheritedUser")),
                "Should collect InheritedUser type");
        // AdminUser should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("AdminUser")),
                "Should collect AdminUser type");
        // UserStatus enum should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("UserStatus")),
                "Should collect UserStatus enum type");
        // Generic Result type should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("Result")),
                "Should collect Result generic type");
        // Inner classes should be found
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("Order")),
                "Should collect Order inner class");
        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("OrderItem")),
                "Should collect OrderItem inner class");
    }

    @Test
    void shouldNotCollectJdkTypes() {
        TypeAnalyzer analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        Set<Class<?>> types = analyzer.collectTypes();

        assertFalse(types.stream().anyMatch(t -> t == String.class),
                "Should not collect String");
        assertFalse(types.stream().anyMatch(t -> t == Long.class),
                "Should not collect Long");
        assertFalse(types.stream().anyMatch(t -> t == Integer.class),
                "Should not collect Integer");
    }

    @Test
    void shouldCollectTypesFromSimpleService() {
        TypeAnalyzer analyzer = new TypeAnalyzer("com.example.protogen.testservice.SimpleService");
        Set<Class<?>> types = analyzer.collectTypes();

        assertTrue(types.stream().anyMatch(t -> t.getSimpleName().equals("User")),
                "Should collect User from return type");
    }

    @Test
    void shouldReturnEmptyForPackageWithNoRpcMapping() {
        TypeAnalyzer analyzer = new TypeAnalyzer("java.lang");
        Set<Class<?>> types = analyzer.collectTypes();
        assertTrue(types.isEmpty(), "Should return empty set for package with no @RpcMapping");
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=TypeAnalyzerTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR (TypeAnalyzer class not found)

- [ ] **Step 3: Write TypeAnalyzer implementation**

```java
package com.example.protogen;

import com.example.annotation.RpcMapping;
import org.reflections.Reflections;
import org.reflections.scanners.MethodAnnotationsScanner;
import org.reflections.scanners.SubTypesScanner;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.*;

public class TypeAnalyzer {

    private static final Set<String> JDK_TYPES = new HashSet<>(Arrays.asList(
            "java.lang", "java.util", "java.math", "java.time", "java.io"
    ));

    private final String packageName;

    public TypeAnalyzer(String packageName) {
        this.packageName = packageName;
    }

    public Set<Class<?>> collectTypes() {
        Reflections reflections = new Reflections(packageName,
                new MethodAnnotationsScanner(),
                new SubTypesScanner(false));

        Set<Method> methods = reflections.getMethodsAnnotatedWith(RpcMapping.class);
        Set<Class<?>> types = new LinkedHashSet<>();

        for (Method method : methods) {
            // Process parameter types
            for (java.lang.reflect.Parameter param : method.getParameters()) {
                collectType(param.getParameterizedType(), types, reflections);
            }
            // Process return type
            collectType(method.getGenericReturnType(), types, reflections);
        }

        return types;
    }

    private void collectType(Type type, Set<Class<?>> types, Reflections reflections) {
        if (type instanceof Class) {
            collectClass((Class<?>) type, types, reflections);
        } else if (type instanceof ParameterizedType) {
            ParameterizedType pt = (ParameterizedType) type;
            // Collect raw type
            collectClass((Class<?>) pt.getRawType(), types, reflections);
            // Collect type arguments
            for (Type arg : pt.getActualTypeArguments()) {
                collectType(arg, types, reflections);
            }
        }
        // TypeVariable and WildcardType are skipped here
    }

    private void collectClass(Class<?> clazz, Set<Class<?>> types, Reflections reflections) {
        if (clazz.isPrimitive()) return;
        if (clazz.isArray()) {
            collectClass(clazz.getComponentType(), types, reflections);
            return;
        }
        if (isJdkType(clazz)) return;
        if (types.contains(clazz)) return;

        types.add(clazz);

        // Recurse into superclass
        Class<?> superclass = clazz.getSuperclass();
        if (superclass != null && superclass != Object.class && !isJdkType(superclass)) {
            collectClass(superclass, types, reflections);
        }

        // Recurse into declared fields
        for (Field field : clazz.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) continue;
            collectType(field.getGenericType(), types, reflections);
        }
    }

    static boolean isJdkType(Class<?> clazz) {
        if (clazz.isPrimitive()) return true;
        Package pkg = clazz.getPackage();
        if (pkg == null) return false;
        String pkgName = pkg.getName();
        for (String prefix : JDK_TYPES) {
            if (pkgName.startsWith(prefix)) return true;
        }
        return false;
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=TypeAnalyzerTest
```
Expected: All tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/test/java/com/example/protogen/testservice/ src/main/java/com/example/protogen/TypeAnalyzer.java src/test/java/com/example/protogen/TypeAnalyzerTest.java
git commit -m "feat: add TypeAnalyzer for collecting POJO types from @RpcMapping methods"
```

---

### Task 3: TypeResolver — resolve inheritance, enums, generics, field types

**Files:**
- Create: `src/main/java/com/example/protogen/TypeResolver.java`
- Create: `src/main/java/com/example/protogen/ResolvedType.java`
- Create: `src/main/java/com/example/protogen/ResolvedField.java`
- Create: `src/test/java/com/example/protogen/TypeResolverTest.java`

- [ ] **Step 1: Write ResolvedType and ResolvedField model classes**

```java
// ResolvedField.java
package com.example.protogen;

import java.util.Objects;

public class ResolvedField {
    private String name;
    private String protoType;
    private boolean repeated;
    private boolean isMap;
    private String mapKeyType;
    private String mapValueType;
    private int fieldNumber;
    private String comment;
    private boolean genericType;
    private String genericVarName;

    public ResolvedField(String name, String protoType) {
        this.name = name;
        this.protoType = protoType;
    }

    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getProtoType() { return protoType; }
    public void setProtoType(String protoType) { this.protoType = protoType; }

    public boolean isRepeated() { return repeated; }
    public void setRepeated(boolean repeated) { this.repeated = repeated; }

    public boolean isMap() { return isMap; }
    public void setMap(boolean map) { isMap = map; }

    public String getMapKeyType() { return mapKeyType; }
    public void setMapKeyType(String mapKeyType) { this.mapKeyType = mapKeyType; }

    public String getMapValueType() { return mapValueType; }
    public void setMapValueType(String mapValueType) { this.mapValueType = mapValueType; }

    public int getFieldNumber() { return fieldNumber; }
    public void setFieldNumber(int fieldNumber) { this.fieldNumber = fieldNumber; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public boolean isGenericType() { return genericType; }
    public void setGenericType(boolean genericType) { this.genericType = genericType; }

    public String getGenericVarName() { return genericVarName; }
    public void setGenericVarName(String genericVarName) { this.genericVarName = genericVarName; }
}
```

```java
// ResolvedType.java
package com.example.protogen;

import java.util.ArrayList;
import java.util.List;

public class ResolvedType {
    private Class<?> clazz;
    private String messageName;
    private boolean isEnum;
    private List<String> enumValues = new ArrayList<>();
    private String parentName; // for inheritance: null if none
    private List<ResolvedField> fields = new ArrayList<>();
    private String comment;

    public Class<?> getClazz() { return clazz; }
    public void setClazz(Class<?> clazz) { this.clazz = clazz; }

    public String getMessageName() { return messageName; }
    public void setMessageName(String messageName) { this.messageName = messageName; }

    public boolean isEnum() { return isEnum; }
    public void setEnum(boolean anEnum) { isEnum = anEnum; }

    public List<String> getEnumValues() { return enumValues; }
    public void setEnumValues(List<String> enumValues) { this.enumValues = enumValues; }

    public String getParentName() { return parentName; }
    public void setParentName(String parentName) { this.parentName = parentName; }

    public List<ResolvedField> getFields() { return fields; }
    public void setFields(List<ResolvedField> fields) { this.fields = fields; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
}
```

- [ ] **Step 2: Write TypeResolverTest**

```java
package com.example.protogen;

import com.example.protogen.testservice.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class TypeResolverTest {

    private TypeAnalyzer analyzer;
    private TypeResolver resolver;

    @BeforeEach
    void setUp() {
        analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        resolver = new TypeResolver();
    }

    @Test
    void shouldResolveSimpleType() throws Exception {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType userType = resolved.stream()
                .filter(t -> t.getMessageName().equals("User"))
                .findFirst().orElse(null);
        assertNotNull(userType, "User type should be resolved");
        assertFalse(userType.isEnum(), "User should not be enum");
        assertNull(userType.getParentName(), "SimpleService.User has no parent");
        assertEquals(2, userType.getFields().size(), "User should have 2 fields");
    }

    @Test
    void shouldResolveInheritanceChain() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType baseEntity = resolved.stream()
                .filter(t -> t.getMessageName().equals("BaseEntity"))
                .findFirst().orElse(null);
        assertNotNull(baseEntity);
        assertNull(baseEntity.getParentName(), "BaseEntity has no parent");

        ResolvedType inheritedUser = resolved.stream()
                .filter(t -> t.getMessageName().equals("InheritedUser"))
                .findFirst().orElse(null);
        assertNotNull(inheritedUser);
        assertEquals("BaseEntity", inheritedUser.getParentName(),
                "InheritedUser should extend BaseEntity");

        // AdminUser extends InheritedUser extends BaseEntity
        ResolvedType adminUser = resolved.stream()
                .filter(t -> t.getMessageName().equals("AdminUser"))
                .findFirst().orElse(null);
        assertNotNull(adminUser);
        assertEquals("InheritedUser", adminUser.getParentName(),
                "AdminUser should extend InheritedUser");
    }

    @Test
    void shouldResolveEnum() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType statusEnum = resolved.stream()
                .filter(t -> t.getMessageName().equals("UserStatus"))
                .findFirst().orElse(null);
        assertNotNull(statusEnum, "UserStatus enum should be resolved");
        assertTrue(statusEnum.isEnum(), "UserStatus should be enum");
        assertTrue(statusEnum.getEnumValues().contains("ACTIVE"), "Should contain ACTIVE");
        assertTrue(statusEnum.getEnumValues().contains("INACTIVE"), "Should contain INACTIVE");
        assertTrue(statusEnum.getEnumValues().contains("SUSPENDED"), "Should contain SUSPENDED");
    }

    @Test
    void shouldResolveGenericType() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);

        ResolvedType resultType = resolved.stream()
                .filter(t -> t.getMessageName().equals("Result"))
                .findFirst().orElse(null);
        assertNotNull(resultType, "Result generic type should be resolved");

        // data field with generic type T should be marked as generic
        ResolvedField dataField = resultType.getFields().stream()
                .filter(f -> f.getName().equals("data"))
                .findFirst().orElse(null);
        assertNotNull(dataField, "data field should exist");
        assertTrue(dataField.isGenericType(), "data field should be generic");
        assertEquals("bytes", dataField.getProtoType(), "Generic field proto type should be bytes");
        assertEquals("T", dataField.getGenericVarName(), "Generic var name should be T");
    }

    @Test
    void shouldDetectCyclicReference() {
        // Create a cycle: A → B → A
        // This test verifies no StackOverflowError
        Set<Class<?>> types = analyzer.collectTypes();
        assertDoesNotThrow(() -> resolver.resolve(types),
                "Should handle cyclic references without exception");
    }
}
```

- [ ] **Step 3: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=TypeResolverTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR (TypeResolver class not found)

- [ ] **Step 4: Write TypeResolver implementation**

```java
package com.example.protogen;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.*;

public class TypeResolver {

    private static final Map<Class<?>, String> PRIMITIVE_MAP = new LinkedHashMap<>();
    static {
        PRIMITIVE_MAP.put(int.class, "int32");
        PRIMITIVE_MAP.put(Integer.class, "int32");
        PRIMITIVE_MAP.put(long.class, "int64");
        PRIMITIVE_MAP.put(Long.class, "int64");
        PRIMITIVE_MAP.put(float.class, "float");
        PRIMITIVE_MAP.put(Float.class, "float");
        PRIMITIVE_MAP.put(double.class, "double");
        PRIMITIVE_MAP.put(Double.class, "double");
        PRIMITIVE_MAP.put(boolean.class, "bool");
        PRIMITIVE_MAP.put(Boolean.class, "bool");
        PRIMITIVE_MAP.put(String.class, "string");
        PRIMITIVE_MAP.put(byte[].class, "bytes");
        PRIMITIVE_MAP.put(Byte[].class, "bytes");
        PRIMITIVE_MAP.put(java.util.Date.class, "int64");
        PRIMITIVE_MAP.put(java.sql.Date.class, "int64");
        PRIMITIVE_MAP.put(java.time.LocalDateTime.class, "int64");
        PRIMITIVE_MAP.put(java.time.LocalDate.class, "int64");
    }

    private Set<Class<?>> processed = new HashSet<>();

    public List<ResolvedType> resolve(Set<Class<?>> types) {
        processed.clear();
        List<ResolvedType> result = new ArrayList<>();

        List<Class<?>> sorted = topologicalSort(types);
        for (Class<?> clazz : sorted) {
            if (!processed.contains(clazz)) {
                ResolvedType resolved = resolveType(clazz, types);
                if (resolved != null) {
                    result.add(resolved);
                }
            }
        }
        return result;
    }

    private ResolvedType resolveType(Class<?> clazz, Set<Class<?>> allTypes) {
        if (processed.contains(clazz)) return null;
        processed.add(clazz);

        if (clazz.isEnum()) {
            ResolvedType rt = new ResolvedType();
            rt.setClazz(clazz);
            rt.setMessageName(clazz.getSimpleName());
            rt.setEnum(true);
            for (Object constant : clazz.getEnumConstants()) {
                Enum<?> e = (Enum<?>) constant;
                rt.getEnumValues().add(e.name());
            }
            return rt;
        }

        ResolvedType rt = new ResolvedType();
        rt.setClazz(clazz);
        rt.setMessageName(clazz.getSimpleName());

        // Resolve inheritance
        Class<?> superclass = clazz.getSuperclass();
        if (superclass != null && superclass != Object.class
                && !TypeAnalyzer.isJdkType(superclass) && allTypes.contains(superclass)) {
            // Ensure parent is resolved first
            resolveType(superclass, allTypes);
            rt.setParentName(superclass.getSimpleName());
        }

        // Resolve fields
        int fieldIndex = 0;
        for (Field field : clazz.getDeclaredFields()) {
            if (Modifier.isStatic(field.getModifiers())) continue;
            if (Modifier.isTransient(field.getModifiers())) continue;

            ResolvedField rf = resolveField(field);
            if (rf != null) {
                rf.setFieldNumber(++fieldIndex);
                rt.getFields().add(rf);
            }
        }

        return rt;
    }

    private ResolvedField resolveField(Field field) {
        Type genericType = field.getGenericType();

        if (genericType instanceof TypeVariable) {
            TypeVariable<?> tv = (TypeVariable<?>) genericType;
            ResolvedField rf = new ResolvedField(field.getName(), "bytes");
            rf.setGenericType(true);
            rf.setGenericVarName(tv.getName());
            rf.setComment("generic type " + tv.getName());
            return rf;
        }

        if (genericType instanceof ParameterizedType) {
            ParameterizedType pt = (ParameterizedType) genericType;
            Class<?> rawType = (Class<?>) pt.getRawType();

            if (isListLike(rawType)) {
                Type arg = pt.getActualTypeArguments()[0];
                String elemType = toProtoType(arg, true);
                ResolvedField rf = new ResolvedField(field.getName(), elemType);
                rf.setRepeated(true);
                return rf;
            }

            if (isMapLike(rawType)) {
                Type keyArg = pt.getActualTypeArguments()[0];
                Type valArg = pt.getActualTypeArguments()[1];
                String keyType = toProtoType(keyArg, false);
                String valType = toProtoType(valArg, false);
                ResolvedField rf = new ResolvedField(field.getName(), valType);
                rf.setMap(true);
                rf.setMapKeyType(keyType);
                rf.setMapValueType(valType);
                return rf;
            }

            if (isOptional(rawType)) {
                Type arg = pt.getActualTypeArguments()[0];
                String innerType = toProtoType(arg, true);
                return new ResolvedField(field.getName(), innerType);
            }

            // Other parameterized types — generic fallback
            ResolvedField rf = new ResolvedField(field.getName(), "bytes");
            StringBuilder comment = new StringBuilder("generic type <");
            for (int i = 0; i < pt.getActualTypeArguments().length; i++) {
                if (i > 0) comment.append(", ");
                comment.append(pt.getActualTypeArguments()[i].getTypeName());
            }
            comment.append(">");
            rf.setComment(comment.toString());
            return rf;
        }

        if (genericType instanceof Class) {
            Class<?> type = (Class<?>) genericType;
            String protoType = toProtoType(type, true);
            return new ResolvedField(field.getName(), protoType);
        }

        return null;
    }

    private String toProtoType(Type type, boolean useSimpleName) {
        if (type instanceof Class) {
            Class<?> clazz = (Class<?>) type;
            String mapped = PRIMITIVE_MAP.get(clazz);
            if (mapped != null) return mapped;
            if (TypeAnalyzer.isJdkType(clazz)) {
                // Fallback for unknown JDK types
                return "bytes";
            }
            return clazz.getSimpleName();
        }
        if (type instanceof ParameterizedType) {
            return toProtoType(((ParameterizedType) type).getRawType(), useSimpleName);
        }
        if (type instanceof TypeVariable) {
            return "bytes";
        }
        return "bytes";
    }

    // Use raw Class-based overload for existing calls
    private String toProtoType(Class<?> type, boolean useSimpleName) {
        String mapped = PRIMITIVE_MAP.get(type);
        if (mapped != null) return mapped;
        if (TypeAnalyzer.isJdkType(type)) return "bytes";
        return type.getSimpleName();
    }

    private boolean isListLike(Class<?> clazz) {
        return List.class.isAssignableFrom(clazz)
                || Set.class.isAssignableFrom(clazz)
                || Collection.class.isAssignableFrom(clazz);
    }

    private boolean isMapLike(Class<?> clazz) {
        return Map.class.isAssignableFrom(clazz);
    }

    private boolean isOptional(Class<?> clazz) {
        return Optional.class == clazz;
    }

    private List<Class<?>> topologicalSort(Set<Class<?>> types) {
        List<Class<?>> sorted = new ArrayList<>();
        Set<Class<?>> visited = new HashSet<>();

        for (Class<?> type : types) {
            dfs(type, types, visited, sorted);
        }
        return sorted;
    }

    private void dfs(Class<?> type, Set<Class<?>> allTypes,
                     Set<Class<?>> visited, List<Class<?>> sorted) {
        if (visited.contains(type)) return;
        visited.add(type);

        Class<?> superclass = type.getSuperclass();
        if (superclass != null && superclass != Object.class
                && !TypeAnalyzer.isJdkType(superclass) && allTypes.contains(superclass)) {
            dfs(superclass, allTypes, visited, sorted);
        }

        sorted.add(type);
    }
}
```

- [ ] **Step 5: Run test to verify it passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=TypeResolverTest
```
Expected: All tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/main/java/com/example/protogen/ResolvedType.java src/main/java/com/example/protogen/ResolvedField.java src/main/java/com/example/protogen/TypeResolver.java src/test/java/com/example/protogen/TypeResolverTest.java
git commit -m "feat: add TypeResolver for inheritance, enums, generics resolution"
```

---

### Task 4: ProtoFileGenerator (single-file mode)

**Files:**
- Create: `src/main/java/com/example/protogen/FieldNumberAllocator.java`
- Create: `src/main/java/com/example/protogen/ProtoFileGenerator.java`
- Create: `src/test/java/com/example/protogen/ProtoFileGeneratorTest.java`

- [ ] **Step 1: Write FieldNumberAllocator**

```java
package com.example.protogen;

public class FieldNumberAllocator {
    private int current = 0;

    public int next() {
        return ++current;
    }

    public void reset() {
        current = 0;
    }
}
```

- [ ] **Step 2: Write ProtoFileGeneratorTest**

```java
package com.example.protogen;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoFileGeneratorTest {

    private TypeAnalyzer analyzer;
    private TypeResolver resolver;
    private ProtoFileGenerator generator;

    @BeforeEach
    void setUp() {
        analyzer = new TypeAnalyzer("com.example.protogen.testservice");
        resolver = new TypeResolver();
        generator = new ProtoFileGenerator();
    }

    @Test
    void shouldGenerateValidProto2Header() {
        Set<Class<?>> types = analyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example.protogen", "com.example.protogen");

        assertTrue(output.startsWith("syntax = \"proto2\";"),
                "Should start with proto2 syntax declaration");
        assertTrue(output.contains("package com.example.protogen;"),
                "Should contain package declaration");
    }

    @Test
    void shouldGenerateMessageForSimpleType() throws Exception {
        TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.SimpleService");
        Set<Class<?>> types = localAnalyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message User {"), "Should generate User message");
        assertTrue(output.contains("optional string name = 1;"), "Should have name field");
        assertTrue(output.contains("optional int32 age = 2;"), "Should have age field");
    }

    @Test
    void shouldGenerateInheritanceWithComposition() throws Exception {
        TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.InheritanceService");
        Set<Class<?>> types = localAnalyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message BaseEntity {"));
        assertTrue(output.contains("message InheritedUser {"));
        assertTrue(output.contains("// 继承自 BaseEntity"),
                "Should have inheritance comment");
        assertTrue(output.contains("optional BaseEntity baseEntity = 1;"),
                "Parent field should be field 1");
    }

    @Test
    void shouldGenerateEnum() throws Exception {
        TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.EnumService");
        Set<Class<?>> types = localAnalyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("enum UserStatus {"), "Should generate UserStatus enum");
        assertTrue(output.contains("ACTIVE = 0;"), "Enum values should start at 0");
        assertTrue(output.contains("INACTIVE = 1;"));
        assertTrue(output.contains("SUSPENDED = 2;"));
    }

    @Test
    void shouldGenerateGenericTypeAsBytes() throws Exception {
        TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.GenericService");
        Set<Class<?>> types = localAnalyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message Result {"));
        assertTrue(output.contains("optional bytes data = 3;"),
                "Generic field should be bytes");
        assertTrue(output.contains("generic type T"),
                "Should have generic type comment");
    }

    @Test
    void shouldGenerateInnerClassesAsSeparateMessages() throws Exception {
        TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.InnerClassService");
        Set<Class<?>> types = localAnalyzer.collectTypes();
        List<ResolvedType> resolved = resolver.resolve(types);
        String output = generator.generateSingleFile(resolved, "com.example", "com.example.protogen");

        assertTrue(output.contains("message Order {"), "Should generate Order message");
        assertTrue(output.contains("message OrderItem {"), "Should generate OrderItem message");
    }

    @Test
    void shouldHandleEmptyTypes() {
        String output = generator.generateSingleFile(Collections.emptyList(), "com.example", "com.example");
        assertTrue(output.contains("syntax = \"proto2\";"),
                "Empty list should still produce valid header");
    }
}
```

- [ ] **Step 3: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoFileGeneratorTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR (ProtoFileGenerator not found)

- [ ] **Step 4: Write ProtoFileGenerator implementation**

```java
package com.example.protogen;

import java.util.List;

public class ProtoFileGenerator {

    private final FieldNumberAllocator fieldNumberAllocator = new FieldNumberAllocator();

    public String generateSingleFile(List<ResolvedType> types, String javaPackage, String protoPackage) {
        StringBuilder sb = new StringBuilder();
        sb.append("syntax = \"proto2\";\n\n");
        sb.append("package ").append(protoPackage).append(";\n\n");
        sb.append("option java_package = \"").append(javaPackage).append("\";\n\n");

        for (ResolvedType type : types) {
            if (type.isEnum()) {
                generateEnum(sb, type);
            } else {
                generateMessage(sb, type);
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    private void generateMessage(StringBuilder sb, ResolvedType type) {
        if (type.getParentName() != null) {
            sb.append("// 继承自 ").append(type.getParentName()).append("\n");
        }
        sb.append("message ").append(type.getMessageName()).append(" {\n");

        fieldNumberAllocator.reset();

        // If has parent, first field references parent (composition for inheritance)
        if (type.getParentName() != null) {
            int num = fieldNumberAllocator.next();
            String parentField = toLowerCamel(type.getParentName());
            sb.append("  optional ").append(type.getParentName())
              .append(" ").append(parentField)
              .append(" = ").append(num).append(";  // 继承自 ")
              .append(type.getParentName()).append("\n");
        }

        for (ResolvedField field : type.getFields()) {
            int num = fieldNumberAllocator.next();

            if (field.isMap()) {
                sb.append("  map<").append(field.getMapKeyType())
                  .append(", ").append(field.getMapValueType())
                  .append("> ").append(field.getName())
                  .append(" = ").append(num).append(";\n");
            } else if (field.isRepeated()) {
                sb.append("  repeated ").append(field.getProtoType())
                  .append(" ").append(field.getName())
                  .append(" = ").append(num).append(";\n");
            } else {
                sb.append("  optional ").append(field.getProtoType())
                  .append(" ").append(field.getName())
                  .append(" = ").append(num).append(";");
                if (field.isGenericType()) {
                    sb.append("  // generic type ").append(field.getGenericVarName());
                } else if (field.getComment() != null && !field.getComment().isEmpty()) {
                    sb.append("  // ").append(field.getComment());
                }
                sb.append("\n");
            }
        }

        sb.append("}\n");
    }

    private void generateEnum(StringBuilder sb, ResolvedType type) {
        sb.append("enum ").append(type.getMessageName()).append(" {\n");
        for (int i = 0; i < type.getEnumValues().size(); i++) {
            sb.append("  ").append(type.getEnumValues().get(i))
              .append(" = ").append(i).append(";\n");
        }
        sb.append("}\n");
    }

    static String toLowerCamel(String name) {
        if (name == null || name.isEmpty()) return name;
        return Character.toLowerCase(name.charAt(0)) + name.substring(1);
    }
}
```

- [ ] **Step 5: Run test to verify it passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoFileGeneratorTest
```
Expected: All tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/main/java/com/example/protogen/FieldNumberAllocator.java src/main/java/com/example/protogen/ProtoFileGenerator.java src/test/java/com/example/protogen/ProtoFileGeneratorTest.java
git commit -m "feat: add ProtoFileGenerator for single-file proto2 output"
```

---

### Task 5: ProtoFileGenerator multi-file mode + ProtoImportManager

**Files:**
- Create: `src/main/java/com/example/protogen/ProtoImportManager.java`
- Modify: `src/main/java/com/example/protogen/ProtoFileGenerator.java`
- Create: `src/test/java/com/example/protogen/ProtoImportManagerTest.java`

- [ ] **Step 1: Write ProtoImportManagerTest**

```java
package com.example.protogen;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoImportManagerTest {

    @Test
    void shouldManageImportForTypeInDifferentFile() {
        ProtoImportManager mgr = new ProtoImportManager();

        // Type A is defined in BaseTypes.proto
        mgr.registerDefinition("BaseEntity", "BaseEntity");
        // Type B uses Type A
        mgr.addReference("InheritedUser", "BaseEntity");

        Set<String> imports = mgr.getImportsFor("InheritedUser");
        assertEquals(1, imports.size(), "Should have one import");
        assertTrue(imports.contains("BaseEntity.proto"),
                "Should import BaseEntity.proto");
    }

    @Test
    void shouldNotImportTypesInSameFile() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("User", "User");
        mgr.addReference("User", "Order");
        mgr.registerDefinition("Order", "User");

        // This would mean User is defined in User.proto and references Order which is also in User.proto
        // After registering both in same file:
        mgr.registerDefinition("Order", "User");
        Set<String> imports = mgr.getImportsFor("User");
        assertTrue(imports.isEmpty(), "No import needed if both in same file");
    }

    @Test
    void shouldHandleNoReferences() {
        ProtoImportManager mgr = new ProtoImportManager();
        mgr.registerDefinition("Standalone", "Standalone");
        Set<String> imports = mgr.getImportsFor("Standalone");
        assertTrue(imports.isEmpty(), "Standalone type should have no imports");
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoImportManagerTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR

- [ ] **Step 3: Write ProtoImportManager**

```java
package com.example.protogen;

import java.util.*;

public class ProtoImportManager {

    // Map: typeName → fileName (without .proto extension)
    private final Map<String, String> typeToFile = new HashMap<>();
    // Map: fileName → Set of referenced type names
    private final Map<String, Set<String>> fileReferences = new HashMap<>();

    public void registerDefinition(String typeName, String fileName) {
        typeToFile.put(typeName, fileName);
    }

    public void addReference(String sourceTypeName, String referencedTypeName) {
        String sourceFile = typeToFile.get(sourceTypeName);
        if (sourceFile == null) return;

        fileReferences.computeIfAbsent(sourceFile, k -> new LinkedHashSet<>())
                .add(referencedTypeName);
    }

    public void addReference(String sourceTypeName, String referencedTypeName,
                             String referencedFile) {
        typeToFile.putIfAbsent(referencedTypeName, referencedFile);
        addReference(sourceTypeName, referencedTypeName);
    }

    public Set<String> getImportsFor(String typeName) {
        String sourceFile = typeToFile.get(typeName);
        if (sourceFile == null) return Collections.emptySet();

        Set<String> imports = new LinkedHashSet<>();
        Set<String> refs = fileReferences.getOrDefault(sourceFile, Collections.emptySet());

        for (String ref : refs) {
            String refFile = typeToFile.get(ref);
            if (refFile != null && !refFile.equals(sourceFile)) {
                imports.add(refFile + ".proto");
            }
        }
        return imports;
    }

    public String getFileName(String typeName) {
        return typeToFile.get(typeName);
    }
}
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoImportManagerTest
```
Expected: All tests PASS

- [ ] **Step 5: Add multi-file generation methods to ProtoFileGenerator**

Append to ProtoFileGenerator:

```java
public Map<String, String> generateMultiFile(List<ResolvedType> types,
                                               String javaPackage,
                                               String protoPackage) {
    ProtoImportManager importMgr = new ProtoImportManager();

    // Register all type definitions (one file per type)
    for (ResolvedType type : types) {
        String fileName = type.getMessageName();
        importMgr.registerDefinition(type.getMessageName(), fileName);
    }

    // Register cross-references
    for (ResolvedType type : types) {
        if (type.getParentName() != null) {
            importMgr.addReference(type.getMessageName(), type.getParentName());
        }
        for (ResolvedField field : type.getFields()) {
            String refType = field.getProtoType();
            if (importMgr.getFileName(refType) != null
                    && !refType.equals(type.getMessageName())) {
                importMgr.addReference(type.getMessageName(), refType);
            }
        }
    }

    // Generate one file per type
    Map<String, String> files = new LinkedHashMap<>();
    for (ResolvedType type : types) {
        StringBuilder sb = new StringBuilder();
        sb.append("syntax = \"proto2\";\n\n");
        sb.append("package ").append(protoPackage).append(";\n\n");
        sb.append("option java_package = \"").append(javaPackage).append("\";\n\n");

        // Add imports
        Set<String> imports = importMgr.getImportsFor(type.getMessageName());
        for (String imp : imports) {
            sb.append("import \"").append(imp).append("\";\n");
        }
        if (!imports.isEmpty()) {
            sb.append("\n");
        }

        // Generate the type
        if (type.isEnum()) {
            generateEnum(sb, type);
        } else {
            generateMessage(sb, type);
        }

        files.put(type.getMessageName() + ".proto", sb.toString());
    }

    return files;
}
```

Add imports to ProtoFileGenerator.java:
```java
import java.util.*;
```

- [ ] **Step 6: Add multi-file tests to ProtoFileGeneratorTest**

```java
@Test
void shouldGenerateMultiFileOutput() throws Exception {
    TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.InheritanceService");
    Set<Class<?>> types = localAnalyzer.collectTypes();
    List<ResolvedType> resolved = resolver.resolve(types);
    Map<String, String> files = generator.generateMultiFile(resolved, "com.example.protogen", "com.example.protogen");

    assertTrue(files.containsKey("BaseEntity.proto"), "Should generate BaseEntity.proto");
    assertTrue(files.containsKey("InheritedUser.proto"), "Should generate InheritedUser.proto");
    assertTrue(files.containsKey("AdminUser.proto"), "Should generate AdminUser.proto");
}

@Test
void multiFileShouldContainImportForParentType() throws Exception {
    TypeAnalyzer localAnalyzer = new TypeAnalyzer("com.example.protogen.testservice.InheritanceService");
    Set<Class<?>> types = localAnalyzer.collectTypes();
    List<ResolvedType> resolved = resolver.resolve(types);
    Map<String, String> files = generator.generateMultiFile(resolved, "com.example.protogen", "com.example.protogen");

    String inhertedUserContent = files.get("InheritedUser.proto");
    assertNotNull(inhertedUserContent);
    assertTrue(inhertedUserContent.contains("import \"BaseEntity.proto\";"),
            "InheritedUser.proto should import BaseEntity.proto");

    String adminContent = files.get("AdminUser.proto");
    assertNotNull(adminContent);
    assertTrue(adminContent.contains("import \"InheritedUser.proto\";"),
            "AdminUser.proto should import InheritedUser.proto");
}
```

- [ ] **Step 7: Run tests to verify multi-file mode passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoFileGeneratorTest
```
Expected: All tests PASS (both old and new tests)

- [ ] **Step 8: Commit**

```bash
git add src/main/java/com/example/protogen/ProtoImportManager.java src/main/java/com/example/protogen/ProtoFileGenerator.java src/test/java/com/example/protogen/ProtoImportManagerTest.java
git commit -m "feat: add multi-file mode with ProtoImportManager"
```

---

### Task 6: ProtoWriter — file output

**Files:**
- Create: `src/main/java/com/example/protogen/ProtoWriter.java`
- Create: `src/test/java/com/example/protogen/ProtoWriterTest.java`

- [ ] **Step 1: Write ProtoWriterTest**

```java
package com.example.protogen;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ProtoWriterTest {

    @TempDir
    Path tempDir;

    @Test
    void shouldWriteSingleFile() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        String content = "syntax = \"proto2\";\n\nmessage Test {}\n";
        Path outputPath = tempDir.resolve("output.proto");

        writer.writeSingleFile(content, outputPath);

        assertTrue(Files.exists(outputPath), "File should exist");
        String written = Files.readString(outputPath);
        assertEquals(content, written, "Content should match");
    }

    @Test
    void shouldWriteMultipleFiles() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        Map<String, String> files = new LinkedHashMap<>();
        files.put("Test1.proto", "message Test1 {}");
        files.put("Test2.proto", "message Test2 {}");
        Path outputDir = tempDir.resolve("proto");

        writer.writeMultiFile(files, outputDir);

        assertTrue(Files.exists(outputDir.resolve("Test1.proto")), "Test1.proto should exist");
        assertTrue(Files.exists(outputDir.resolve("Test2.proto")), "Test2.proto should exist");
        assertEquals("message Test1 {}", Files.readString(outputDir.resolve("Test1.proto")));
    }

    @Test
    void shouldCreateOutputDirectoryIfNotExists() throws IOException {
        ProtoWriter writer = new ProtoWriter();
        Path deepDir = tempDir.resolve("a/b/c");
        writer.writeSingleFile("content", deepDir.resolve("test.proto"));

        assertTrue(Files.exists(deepDir), "Directory should be created");
        assertTrue(Files.exists(deepDir.resolve("test.proto")));
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoWriterTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR

- [ ] **Step 3: Write ProtoWriter**

```java
package com.example.protogen;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class ProtoWriter {

    public void writeSingleFile(String content, Path outputPath) throws IOException {
        Files.createDirectories(outputPath.getParent());
        Files.writeString(outputPath, content);
    }

    public void writeMultiFile(Map<String, String> files, Path outputDir) throws IOException {
        Files.createDirectories(outputDir);
        for (Map.Entry<String, String> entry : files.entrySet()) {
            Path filePath = outputDir.resolve(entry.getKey());
            Files.writeString(filePath, entry.getValue());
        }
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=ProtoWriterTest
```
Expected: All tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/example/protogen/ProtoWriter.java src/test/java/com/example/protogen/ProtoWriterTest.java
git commit -m "feat: add ProtoWriter for file output"
```

---

### Task 7: PojoToProtoGenerator — orchestrator + integration test

**Files:**
- Create: `src/main/java/com/example/protogen/PojoToProtoGenerator.java`
- Create: `src/test/java/com/example/protogen/PojoToProtoGeneratorTest.java`
- Modify: `src/main/java/com/example/App.java` (optional demo)

- [ ] **Step 1: Write PojoToProtoGeneratorTest**

```java
package com.example.protogen;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PojoToProtoGeneratorTest {

    @TempDir
    Path tempDir;

    @Test
    void shouldGenerateSingleFileIntegration() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("all.proto");

        generator.generate(
                "com.example.protogen.testservice.SimpleService",
                outputPath,
                true  // single file
        );

        assertTrue(Files.exists(outputPath), "Output file should exist");
        String content = Files.readString(outputPath);
        assertTrue(content.contains("syntax = \"proto2\";"));
        assertTrue(content.contains("message User {"));
        assertTrue(content.contains("optional string name = 1;"));
        assertTrue(content.contains("optional int32 age = 2;"));
    }

    @Test
    void shouldGenerateMultiFileIntegration() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputDir = tempDir.resolve("proto");

        generator.generate(
                "com.example.protogen.testservice.InheritanceService",
                outputDir,
                false  // multi-file
        );

        assertTrue(Files.exists(outputDir.resolve("BaseEntity.proto")));
        assertTrue(Files.exists(outputDir.resolve("InheritedUser.proto")));
        assertTrue(Files.exists(outputDir.resolve("AdminUser.proto")));

        String inheritedUserContent = Files.readString(outputDir.resolve("InheritedUser.proto"));
        assertTrue(inheritedUserContent.contains("import \"BaseEntity.proto\";"));
        assertTrue(inheritedUserContent.contains("// 继承自 BaseEntity"));
    }

    @Test
    void shouldGenerateAllFeaturesCombined() throws IOException {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("combined.proto");

        generator.generate(
                "com.example.protogen.testservice",
                outputPath,
                true
        );

        String content = Files.readString(outputPath);
        // Should contain all features
        assertTrue(content.contains("message User {"));
        assertTrue(content.contains("message BaseEntity {"));
        assertTrue(content.contains("enum UserStatus {"));
        assertTrue(content.contains("message Result {"));
        assertTrue(content.contains("message Order {"));
        assertTrue(content.contains("message OrderItem {"));
    }

    @Test
    void shouldThrowExceptionForEmptyPackage() {
        PojoToProtoGenerator generator = new PojoToProtoGenerator();
        Path outputPath = tempDir.resolve("empty.proto");

        assertThrows(IllegalArgumentException.class, () -> {
            generator.generate("com.example.nonexistent", outputPath, true);
        }, "Should throw if no @RpcMapping methods found");
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=PojoToProtoGeneratorTest -DfailIfNoTests=false
```
Expected: COMPILATION ERROR

- [ ] **Step 3: Write PojoToProtoGenerator**

```java
package com.example.protogen;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PojoToProtoGenerator {

    private final TypeAnalyzer typeAnalyzer;
    private final TypeResolver typeResolver;
    private final ProtoFileGenerator protoFileGenerator;
    private final ProtoWriter protoWriter;

    public PojoToProtoGenerator() {
        this.typeAnalyzer = null; // lazy init per call
        this.typeResolver = new TypeResolver();
        this.protoFileGenerator = new ProtoFileGenerator();
        this.protoWriter = new ProtoWriter();
    }

    /**
     * Generate proto2 file(s) from a package.
     *
     * @param packageName Java package to scan for @RpcMapping
     * @param outputPath If singleFile=true: path to output .proto file.
     *                   If singleFile=false: path to output directory.
     * @param singleFile true = one .proto file, false = one file per type
     */
    public void generate(String packageName, Path outputPath, boolean singleFile)
            throws IOException {

        TypeAnalyzer analyzer = new TypeAnalyzer(packageName);
        Set<Class<?>> rawTypes = analyzer.collectTypes();

        if (rawTypes.isEmpty()) {
            throw new IllegalArgumentException(
                    "No types found in package '" + packageName + "' with @RpcMapping methods");
        }

        List<ResolvedType> resolvedTypes = typeResolver.resolve(rawTypes);
        String javaPackage = deriveJavaPackage(resolvedTypes);

        if (singleFile) {
            String content = protoFileGenerator.generateSingleFile(
                    resolvedTypes, javaPackage, javaPackage);
            protoWriter.writeSingleFile(content, outputPath);
        } else {
            Map<String, String> files = protoFileGenerator.generateMultiFile(
                    resolvedTypes, javaPackage, javaPackage);
            protoWriter.writeMultiFile(files, outputPath);
        }
    }

    private String deriveJavaPackage(List<ResolvedType> types) {
        if (types.isEmpty()) return "unknown";
        Package pkg = types.get(0).getClazz().getPackage();
        return pkg != null ? pkg.getName() : "unknown";
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd d:\workspace\specdemo && mvn test -Dtest=PojoToProtoGeneratorTest
```
Expected: All tests PASS

- [ ] **Step 5: Run ALL tests to verify nothing is broken**

```bash
cd d:\workspace\specdemo && mvn test
```
Expected: All tests PASS (including existing OpenApiConverterTest and RpcScannerTest)

- [ ] **Step 6: Commit**

```bash
git add src/main/java/com/example/protogen/PojoToProtoGenerator.java src/test/java/com/example/protogen/PojoToProtoGeneratorTest.java
git commit -m "feat: add PojoToProtoGenerator orchestrator with integration tests"
```

---

### Task 8: Full integration test — generate real proto output

- [ ] **Step 1: Run full test suite and verify all tests pass**

```bash
cd d:\workspace\specdemo && mvn clean test
```
Expected: BUILD SUCCESS — all existing tests + all new tests pass

- [ ] **Step 2: Manual demo — generate proto from the existing UserService**

Create a temporary test main or run a quick verification:

```bash
cd d:\workspace\specdemo && mvn exec:java -Dexec.mainClass="com.example.App" -Dexec.args="com.example.service ./target/generated.proto true" 2>/dev/null || true
```

(If the exec plugin is not configured, use a test instead.)

- [ ] **Step 3: Final commit**

```bash
git add -A
git commit -m "feat: complete POJO-to-Proto2 generator implementation"
```

---

## Spec Coverage Check

| Spec Requirement | Task |
|---|---|
| Scan package for @RpcMapping methods | Task 2: TypeAnalyzer |
| Recognize method params and return types | Task 2: TypeAnalyzer |
| Convert objects → message | Task 3: TypeResolver → Task 4: ProtoFileGenerator |
| Convert enums → enum | Task 3: TypeResolver (Enum detection) |
| Inheritance support (Message Composition) | Task 3: TypeResolver (parent resolution) |
| Inner classes → separate messages | Task 2: TypeAnalyzer (collects inner classes) |
| Generics: List/Set → repeated | Task 3: TypeResolver |
| Generics: Map → map<K,V> | Task 3: TypeResolver |
| Generics: custom → bytes fallback | Task 3: TypeResolver |
| Enums: no nesting, top-level only | Task 3: TypeResolver (handled by enum detection) |
| Single file mode | Task 4: ProtoFileGenerator.generateSingleFile() |
| Multi-file mode | Task 5: ProtoFileGenerator.generateMultiFile() |
| Proto2 syntax (optional keyword) | Task 4: ProtoFileGenerator (uses `optional` prefix) |
| Field number allocation | Task 4: FieldNumberAllocator |
| Import management (multi-file) | Task 5: ProtoImportManager |
| File output | Task 6: ProtoWriter |
| Orchestrator entry point | Task 7: PojoToProtoGenerator |
